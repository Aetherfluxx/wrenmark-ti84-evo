# 📜 The Wrenmark Grand Charter of License

**Version 1.0 · Year 2026**

*Issued by the High Council of Wrenmark, sealed in Mossbrook, witnessed by PROF. LINDEN and one (1) very sleepy Burrlamb.*

---

## Article I — Ownership

WRENMARK, its region, creatures, towns, routes, gyms, leaders, code and assorted pixels are the personal property of the Holder of this Calculator ("**the Trainer**").

## Article II — Permitted Uses

The Trainer is hereby granted the full, eternal and irrevocable right to:

1. play the game,
2. modify the game,
3. break the game and then fix the game,
4. play it during class at their own risk (see Article V).

## Article III — Forbidden Acts

No one may:

1. sell this game for money, gold, or Poké Balls,
2. claim the Champion was defeated when they were not,
3. insult Tamsin's rocks to her face.

## Article IV — Warranty

This software is provided **"AS IS", "AS WAS", and "AS MAY BE"**. The High Council makes no promise that it will not run out of memory, drain your batteries, or cause you to say "one more route" at 2 a.m.

## Article V — Liability

The High Council is not responsible for confiscated calculators, failed math tests, or emotional damage caused by a critical hit.

## Article VI — Originality

All creatures, places and people herein are original. Any resemblance to other monsters, living or fictional, is coincidental and frankly flattering.

## Article VII — Acceptance

By pressing ENTER on the title screen, the Trainer accepts this Charter in full and solemnly swears to earn all four BADGES with honor, courage, and an unreasonable number of POTIONS.

---

<div align="center">

*Signed and sealed,*

**~ The High Council of Wrenmark ~**

Mossbrook · Cragmoor · Starhaven · Crown Gate

© 2026 · Private · Personal

</div>

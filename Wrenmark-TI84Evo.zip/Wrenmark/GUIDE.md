# WRENMARK — Game Guide

A step-by-step walkthrough from your first step in Mossbrook to the Champion.

> **The whole game is playable**, from choosing your starter to becoming Champion. Recommended levels below come from thousands of simulated battles, and they assume you've caught a few teammates along the way.

---

## Your goal

1. Get a partner Pokémon from PROF. LINDEN.
2. Earn **4 Gym Badges**.
3. Climb Summit Path to Crown Plateau.
4. Defeat the **Elite Four** and the **Champion**.

## Controls

The whole game uses only **6 keys** (the arrow pad counts as one). They're marked with ★ on this map of the TI-84 Evo keypad:

```
   Y=      window   zoom    trace   graph

 ★2ND     ★MODE    ★DEL               ▲
                                   ◄  ★  ►     ← ★ arrow pad
   alpha   X,T,θ,n  stat              ▼

   math    frac     prgm    vars   ★CLEAR

   (number keys and math keys: not used)

   ON      0        .       (−)    ★ENTER
```

| Key | Walking around | In menus & dialog |
|---|---|---|
| **▲ ▼ ◄ ►** (arrow pad) | walk; hold to keep walking | move the cursor / change a number |
| **ENTER** | talk, read signs, interact | confirm / next page |
| **2ND** (blue) | same as ENTER | same as ENTER |
| **CLEAR** | open the start menu | back / cancel |
| **MODE** | open the start menu | — |
| **DEL** | — | back / cancel |

**Not used:** Y= / window / zoom / trace / graph (f1–f5), alpha, X,T,θ,n, stat, math, the fraction key, prgm, vars, the number keys and the math operator keys. Pressing them does nothing.

**ON (the key with the house icon):** on TI calculators this normally stops a running Python program. Treat it as an emergency exit only. Anything since your last save is lost.

### Start menu (CLEAR or MODE)

| Option | What it does |
|---|---|
| POKEMON | your party. Pick one, then choose **SUMMARY** (stats, moves, the level it evolves at) or **SWITCH** (change the order). The Pokémon at the top goes into battle first |
| BAG | your items. Pick one to use it: Potions heal, Revive brings back a fainted Pokémon, and the LEVEL CAP is set here |
| TRAINER | your money, badges, and whether you're Champion |
| SAVE | save your game to one of **3 slots** (see Saving below) |
| LOAD | load any saved slot instantly, like a save state |
| QUIT | leave the game |
| CLOSE | back to walking |

If you see extra options such as **EDITOR** or **WARP**, a cheat code is switched on (see the title screen section below).

### On the title screen

Press **ENTER**. If you have a saved game, choose **CONTINUE** (then pick a slot) or **NEW GAME**. (Psst: secret cheat codes can be typed here. They're listed in `Game/Dev/CHEATS.md`.)

## Battles

Walking through **tall grass**, a **cave**, or **water** (while surfing) can start a battle with a wild Pokémon. Your top party Pokémon goes out first.

Each turn, choose one of four options with the arrows and press ENTER:

| Option | What it does |
|---|---|
| **FIGHT** | pick one of your Pokémon's moves. The bottom bar shows the highlighted move's type and power |
| **BAG** | throw a **POKE BALL** or use a **POTION / SUPER POTION / REVIVE**. Using an item takes your turn |
| **POKEMON** | switch to another Pokémon. Takes your turn |
| **RUN** | escape. Always works against wild Pokémon |

You always move first, then the opponent. There's no speed stat.

**Damage tips:**
- **Same type:** a move that matches its user's own type does 1.5× damage.
- **Critical hits:** these do 2× damage and happen about 1 time in 16.
- **Status moves:** moves with power "-" change stats instead of doing damage, for example raising your DEF or lowering the foe's ATK. They can also heal.

**After winning:** only the Pokémon that knocked the foe out gets EXP. It may level up, learn a new move, and **evolve** once the battle ends.
- With 4 moves already, it asks whether to **forget** one. Choose YES and pick the move to replace, or NO to skip the new move.

**Catching:** BAG → POKE BALL. The lower the wild Pokémon's HP, the better your chances.
- Your 7th Pokémon and beyond go to the **PC**.

**Trainer battles:**
- Trainers challenge you when you walk into their line of sight. A red **!** pops up above them. You can also talk to them.
- Each trainer fights you only once.
- You can't run from a trainer battle or catch their Pokémon.
- They send out their Pokémon one after another.
- Win to earn **prize money**.
- Gym Leaders and the League always use their strongest move, so expect a real fight.

**If all your Pokémon faint:**
- you **black out**,
- you lose **half your money**,
- you wake up at the last place you healed (a Pokémon Center or your house), with your team fully healed.

## Pokémon Center & PC

Walk into a red-roof door and choose:

| Option | What it does |
|---|---|
| **HEAL** | fully heals your party. This also becomes the place you return to if you black out |
| **PC** | **WITHDRAW** a stored Pokémon into your party, or **DEPOSIT** one from your party. Holds up to 50 |
| **LEAVE** | walk away |

## LEVEL CAP

PROF. LINDEN gives you the **LEVEL CAP** together with your starter. It lets a strong Pokémon battle at a lower level, for example to fight early-game Pokémon fairly with your Lv 100 starter.

**To set it:**
1. Open the start menu (CLEAR or MODE).
2. Choose **BAG** → **LEVEL CAP**.
3. Use **◄ / ►** to change the level by 1, or **▲ / ▼** by 10. **0 means OFF.**
4. Press **ENTER**.

**While it's on:**
- Any Pokémon **above** the cap fights as if it were exactly that level. Its HP, ATK and DEF are all lowered to match.
- Its level shows with a star in battle, like **Lv10\***.
- It keeps all its moves.
- Pokémon at or below the cap are unaffected.

**When you set it back to OFF:**
- every Pokémon is back to its real level and stats immediately,
- nothing is lost. The cap only changes how they fight, never their real level.

You can't change the LEVEL CAP during a battle. The summary page shows it too, for example **Lv 100 CAP 10**.

## Saving

There are **3 save slots**. Each one remembers everything: position, party, PC, items, money, badges, beaten trainers and your LEVEL CAP setting.

| How | What happens |
|---|---|
| Start menu → **SAVE** | pick slot 1, 2 or 3. Saving over a different slot asks first |
| Start menu → **LOAD** | jump to any saved slot instantly, like a save state. Unsaved progress is lost |
| Title screen → **CONTINUE** | pick a slot to resume |
| Winning a badge | **autosaves** to the slot you last used. This only happens once you've saved at least once |

The slot list shows each slot's badges and money, so you can tell them apart. Saves are stored on the calculator and survive turning it off.

**Tip:** keep one slot as a backup before big fights, and load it if things go wrong.

## Reading the map

| You see | It means |
|---|---|
| Red roof | **Pokémon Center**. Walk into the door to heal your whole team for free |
| Blue roof | **Mart**. Walk into the door to buy supplies |
| Purple roof with gold trim | **Gym** |
| Brown roof | house. Walk into the door for a tip |
| Dark tall grass | wild Pokémon may appear here (so can caves and water) |
| Wooden sign | press ENTER facing it to read |
| Dark hole in the rock | cave entrance |
| Water | needs SURF (Badge 2) |

## Type cheat sheet

**How to read it:** find your opponent's type in the first column.
- Moves in the **Use** column do **double** damage.
- Moves in the **Avoid** column do **half** damage, or **none at all** where marked.

| Opponent is… | ✅ Use these move types | ❌ Avoid these move types |
|---|---|---|
| Fire | Water, Ground, Rock | Fire, Grass, Ice |
| Water | Grass, Electric | Fire, Water, Ice |
| Grass | Fire, Ice, Flying | Water, Grass, Electric, Ground |
| Normal | Psychic | — |
| Electric | Ground | Electric, Flying |
| Ice | Fire, Rock | Ice |
| Ground | Water, Grass, Ice, Psychic | Rock, **Electric (no effect)** |
| Flying | Electric, Ice, Rock | Grass, **Ground (no effect)** |
| Rock | Water, Grass, Ground | Fire, Normal, Flying |
| Psychic | Electric, Rock | Psychic |

A Pokémon with two types (like Fire/Ground) takes both into account. A move can end up doing 4× damage, or cancelling out to normal.

---

## Step 1 — Mossbrook (start)

- You start outside **your house** (top-left). Walk into its door any time to have Mom heal your team.
- The kid at the north exit won't let you leave yet.
- Walk around the **big lab** at the bottom of town and enter its door from below.
- **PROF. LINDEN** gives you your first Pokémon:

| Starter | Type | Difficulty | Notes |
|---|---|---|---|
| **Burrlamb** | Grass → Grass/Rock | Easy | strong vs. Gym 1 |
| **Wadlet** | Water → Water/Flying | Easy | strong vs. Gym 1 |
| **Sootkit** | Fire → Fire/Ground | Hard start | weak vs. Gym 1, very strong later |

- All three evolve at **Lv 16** and **Lv 34**.
- He also gives you the **LEVEL CAP** item (see the LEVEL CAP section above). You won't need it early on.
- Leave town by the **north** exit.

## Step 2 — Route 1 → Pebblefield

- **Route 1:** walk north.
- Catch a second Pokémon in the tall grass: **Pipwick**, **Nibbin** or **Sprigg**.
  - *Picked Sootkit?* Catch **Sprigg** (Grass). You'll want it for Gym 1.
- One trainer stands on the left side of the route. Trainers challenge you when you walk into their line of sight.
- **Pebblefield:** heal at the Center (top-left) and stock up at the Mart (top-right). Buy **5+ Poké Balls** and a few **Potions**.
- Leave by the **east** exit.

## Step 3 — Route 2 (Briarwood) → Cragmoor

- **Route 2** is a small forest with two trainers.
- New Pokémon here are **Puffcap** and **Moleby**. Moleby is a Ground type and great for both Gym 1 and Gym 2. **Catch one.**
- Continue **east** to **Cragmoor**.

## Step 4 — Gym 1: TAMSIN (Rock) · Cragmoor

- **Where:** the gym is the purple building top-left. The Center is top-right and the Mart bottom-left.
- **Recommended level:** 11–14.
- **Her team:** Pebbit, Tuskore.
- **Use:** Water, Grass or Ground.
- **Avoid:** Fire, Normal and Flying moves.
- **Gym layout:** a straight boulder hall. One trainer stands in the middle and Tamsin is at the top.
- **Reward:** **Badge 1**. The guard blocking Cragmoor's north exit steps aside.

## Step 5 — Route 3 → Duskhollow Cave → Thistledown

- **Route 3:** go north through the hills. Two trainers. New Pokémon: **Pebbit**, **Zappup**.
- The **cave entrance** is the dark hole at the top of the route, where the dirt path ends. Walk up into it.
- **Duskhollow Cave** is a winding tunnel:
  1. From the entrance, go **left**, then **up** the left wall.
  2. Go **right** through the middle tunnels, then **up**.
  3. Follow the upper tunnel back **left**, all the way to the left wall.
  4. Climb **up** the left wall again, then go **right** along the top tunnel to the red exit mat.
  - Wild **Tuskore** and the rare **Dreamlet** live here.
- **Thistledown** is a small village with a Center but **no Mart**. Exit **east**.

## Step 6 — Route 4 → Sparkford

- **Route 4:** grassland with a pond and two trainers. New Pokémon: **Wickle** (Fire), **Lillop** (Water/Grass).
- **Sparkford:** the Center is top-left, the Mart bottom-left and the Gym top-right.

## Step 7 — Gym 2: EZRA (Electric) · Sparkford

- **Recommended level:** 21–24, **and bring a Ground type**.
- **His team:** Zappup, Glidzap, Voltusk.
- **Use:** **Ground** (Electric can't touch it). Moleby/Delvemole, Tuskore and Hedgeroot are ideal.
- **Warning:** this is the hardest early gym if you picked Burrlamb or Wadlet. In testing, a team without a Ground type lost most of the time.
- **Avoid:** Water and Flying Pokémon.
- **Gym layout:** zig-zag lanes. Walk the full width of each lane to reach the gap; trainers wait in the lanes.
- **Reward:** **Badge 2** and **SURF**. Your team can now cross water: just walk into it.
- **Mart:** now stocks **Super Potions**.

## Step 8 — Route 5 (the lake) → Lakemere

- From Sparkford go **north** and **surf** across the lake.
- A trainer lives on the little island. New Pokémon: **Shellk**, **Glidzap**.
- **Lakemere:** Center and Mart are both at the top. Exit **west**.

## Step 9 — Route 6 → Galecrest

- **Route 6:** windy hills, two trainers. New Pokémon: **Mirrin** (Psychic), plus **Pipwick** and **Wickle**.
- **Galecrest:** the Gym is top-left, the Center top-right and the Mart bottom-left.

## Step 10 — Gym 3: CORVIN (Flying) · Galecrest

- **Recommended level:** 26–30.
- **His team:** Gustwing, Glidzap, Aurorwing, Somnowl.
- **Use:** Electric, Ice or Rock.
- **Avoid:** Grass and Ground moves (Ground has no effect).
- **Gym layout:** a 3-lane switchback. The gaps alternate left, right, left. Each lane has a trainer at one end.
- **Reward:** **Badge 3**. The north road out of Galecrest opens.
- **Mart:** now stocks **Revives**.

## Step 11 — Route 7 → Frostfen

- **Route 7:** go north into the cold. Two trainers. New Pokémon: **Frostlet** and **Snowisp** (Ice). Both are great against Gym 3 and against Dorran of the Elite Four.
- **Frostfen:** Center and Mart are at the top. Exit **east**.

## Step 12 — Route 8 → Starhaven

- **Route 8:** **surf** across the river in the middle. Two trainers. New Pokémon: **Dreamlet**, **Mirrin**, **Frostlet**.
- **Starhaven:** the Center is top-left, the Mart bottom-left and the Gym top-right.

## Step 13 — Gym 4: ORLA (Psychic) · Starhaven

- **Recommended level:** 33–38.
- **Her team:** Mirrorix, Toadstule, Somnowl, Mirrorix.
- **Use:** Electric or Rock.
- **Avoid:** Normal and Ground Pokémon (Psychic hits them hard).
- **Gym layout:** a hall of pillars. Trainers watch the rows between them.
- **Reward:** **Badge 4**. You're ready for the League.

## Step 14 — Crown Gate → Summit Path

- **Crown Gate:** the guard lets you through with 4 badges. **Heal and stock up here.** Buy plenty of Super Potions and some Revives.
- **Summit Path** is the last maze, and the strongest wild Pokémon live here:
  - Head **up the middle**, then follow the tunnels on the **right side** up to the top row.
  - Walk **left along the top** to the exit.
  - The left side is a dead end, but it has a trainer if you want the EXP.

## Step 15 — Crown Plateau & the League

- **Heal** at the Center (left side) and buy supplies at the Mart (right side).
- Aim for your team to be around **Lv 45–50**. The Champion is the toughest fight in the game.
- Enter the big building at the top. Inside, five challengers stand in a line. Each steps aside when you win:

| # | Name | Type | Use |
|---|---|---|---|
| 1 | **BRANN** | Ice | Fire, Rock |
| 2 | **DORRAN** | Ground | Water, Grass, Ice |
| 3 | **MARISOL** | Water | Grass, Electric |
| 4 | **KESSA** | Fire | Water, Ground, Rock |
| 5 | **ALDRIC** (Champion) | mixed | a balanced team; bring variety |

- Inside, you can use items between battles. **Save before you go in.**
- If you lose, or walk back out of the hall, the Elite Four start over from the beginning.
- Beat Aldric and you're the **Champion of Wrenmark**. 🏆 After the ending you're back outside, free to keep playing or challenge the League again.

---

## Tips

- **Stuck?** Read the signs and walk into house doors. Most give a hint about the next gym.
- **Team building:** aim for a mix of types. One each of Water, Electric, Ground, Rock and Ice covers almost everything in Wrenmark.
- **Money:** you earn prize money by beating trainers, Gym Leaders and the League.
- **Blacking out** costs half your money, so heal often.
- **EXP:** only the Pokémon in battle when the opponent faints earns EXP. To train a weaker one, move it to the top of your party (start menu → POKEMON → SWITCH).
- **Catching:** weaken the wild Pokémon first. The lower its HP, the easier it is to catch.
- **Saving:** save often, especially before gyms and the League. Three slots means you can keep backups.

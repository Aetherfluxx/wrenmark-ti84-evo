# WRBTL - part of WRENMARK for the TI-84 Evo (built by Dev/tools/build.py)
try:
    import WRCORE as C
except ImportError:
    try:
        import wrcore as C
    except ImportError:
        print('WRENMARK needs WRCORE.py on the calculator too.')
        raise
from random import randint
from time import sleep
ITEMS = (('POKE BALL', 200, 0), ('POTION', 300, 0),
         ('SUPER POTION', 700, 2), ('REVIVE', 1500, 3))
HEAL = (0, 30, 100, 0)
ENC = (
    (((9, 2, 4), (9, 2, 4), (11, 2, 4), (11, 2, 4), (13, 3, 4)), ()),
    (((9, 3, 5), (11, 3, 5), (13, 4, 6), (17, 4, 6), (15, 4, 6)), ()),
    (((15, 8, 10), (22, 8, 10), (19, 9, 11), (11, 8, 10)), ()),
    (((22, 10, 13), (22, 10, 13), (15, 10, 13), (24, 12, 14), (35, 12, 12)), ()),
    (((19, 13, 16), (29, 13, 16), (9, 13, 15), (27, 14, 16)), ()),
    (((27, 20, 23), (21, 21, 24)), ((25, 20, 24), (25, 20, 24), (27, 20, 23))),
    (((10, 26, 28), (21, 25, 28), (37, 25, 27), (29, 25, 27), (9, 24, 25)), ()),
    (((31, 30, 33), (33, 30, 33), (16, 31, 34)), ()),
    (((35, 34, 37), (37, 34, 36), (31, 34, 36)), ((25, 34, 36), (26, 36, 37), (27, 34, 35))),
    (((23, 42, 45), (16, 42, 45), (32, 43, 46), (24, 43, 45), (36, 44, 46)), ()),
)
RATE = {';': 10, 'c': 8, '~': 5}
BG = (248, 248, 240)
CHEATS = ()
CAPPED = []
def roll(enc, tile):
    if enc < 0:
        return None
    lst = ENC[enc][1] if tile == '~' else ENC[enc][0]
    if not lst or randint(1, 100) > RATE[tile]:
        return None
    sp, lo, hi = lst[randint(0, len(lst) - 1)]
    return C.mk(sp, randint(lo, hi))
def name(p):
    return C.SPECIES[p[0]][0]
def blv(G, p):
    return min(p[1], G.cap) if G.cap else p[1]
def bmax(G, p):
    return C.stat(p[0], blv(G, p), 0)
def scale(hp, a, b):
    if hp <= 0:
        return 0
    return max(1, hp * b // a)
def cap_in(G):
    del CAPPED[:]
    for p in G.party:
        if G.cap and p[1] > G.cap:
            p[3] = scale(p[3], C.maxhp(p), bmax(G, p))
            CAPPED.append(p)
def cap_out(G):
    for p in CAPPED:
        p[3] = scale(p[3], bmax(G, p), C.maxhp(p))
    del CAPPED[:]
def foe_box(f):
    C.box(4, 4, 176, 44)
    C.col(C.BLACK)
    C.txt(12, 8, name(f))
    C.txt(126, 8, 'Lv' + str(f[1]))
    C.hpbar(12, 32, 158, f[3], C.maxhp(f))
def me_box(G, p):
    C.box(128, 92, 188, 52)
    C.col(C.BLACK)
    C.txt(136, 96, name(p))
    C.txt(250, 96, 'Lv' + str(blv(G, p)) + ('*' if p in CAPPED else ''))
    mx = bmax(G, p)
    C.hpbar(136, 116, 170, p[3], mx)
    C.col(C.BLACK)
    C.txt(206, 124, str(p[3]) + '/' + str(mx))
def scene(G, p, f):
    C.col(BG)
    C.rect(0, 0, 320, 146)
    C.col((150, 200, 120))
    C.rect(196, 70, 110, 10)
    C.rect(14, 128, 104, 10)
    C.col(C.BAR)
    C.rect(0, 192, 320, 18)
    if f[3] > 0:
        C.icon(250, 46, f[0])
    if p:
        C.icon(64, 106, p[0])
    foe_box(f)
    if p:
        me_box(G, p)
def footer(s):
    C.col(C.BAR)
    C.rect(0, 192, 320, 18)
    C.col(C.WHITE)
    C.txt(4, 193, s)
def grid(items, sel=0, info=None):
    C.box(0, 146, 320, 46)
    C.col(C.BLACK)
    for i in range(len(items)):
        C.txt(28 + (i % 2) * 150, 151 + (i // 2) * 20, items[i])
    while 1:
        if info:
            footer(info(sel))
        C.col(C.BLACK)
        C.txt(14 + (sel % 2) * 150, 151 + (sel // 2) * 20, '>')
        k = C.key()
        if k in C.A_KEYS:
            return sel
        if k in C.B_KEYS:
            return -1
        n = sel
        if k == C.LEFT or k == C.RIGHT:
            n = sel ^ 1
        elif k == C.UP or k == C.DOWN:
            n = sel ^ 2
        if n < len(items):
            C.col(C.WHITE)
            C.rect(14 + (sel % 2) * 150, 151 + (sel // 2) * 20, 12, 18)
            sel = n
def smul(v, s):
    return v * (2 + s) // 2 if s >= 0 else v * 2 // (2 - s)
def stage(st, i, d, who, what):
    v = st[i] + d
    if v > 3 or v < -3:
        return ' ' + who + "'s " + what + " won't go further!"
    st[i] = v
    return ' ' + who + "'s " + what + (' rose!' if d > 0 else ' fell!')
def calc(a, al, ast, d, dl, dst, mid):
    m = C.MOVES[mid]
    e = C.eff(m[1], d[0])
    if not m[2] or not e:
        return 0, e
    A = smul(C.stat(a[0], al, 1), ast[0])
    D = max(smul(C.stat(d[0], dl, 2), dst[1]), 1)
    dmg = ((2 * al // 5 + 2) * m[2] * A // D) // 50 + 2
    s = C.SPECIES[a[0]]
    if m[1] == s[1] or m[1] == s[2]:
        dmg = dmg * 3 // 2
    return dmg * e // 4, e
def ai_move(B):
    f = B[2]
    ms = [m for m in f[4:8] if m] or [1]
    if not B[5] and randint(0, 1):
        return ms[randint(0, len(ms) - 1)]
    G = B[0]
    best = ms[0]
    top = -1
    for m in ms:
        v = calc(f, f[1], B[4], B[1], blv(G, B[1]), B[3], m)[0]
        if v > top:
            best, top = m, v
    return best
def attack(B, mine, mid):
    G = B[0]
    if mine:
        a, d, ast, dst = B[1], B[2], B[3], B[4]
        al, dl = blv(G, a), d[1]
        an, dn = name(a), 'Foe ' + name(d)
    else:
        a, d, ast, dst = B[2], B[1], B[4], B[3]
        al, dl = a[1], blv(G, d)
        an, dn = 'Foe ' + name(a), name(d)
    amx = bmax(G, a) if mine else C.maxhp(a)
    m = C.MOVES[mid]
    C.say(an + ' used ' + m[0] + '!', 0)
    sleep(0.4)
    note = ''
    dmg = 0
    if m[2]:
        dmg, e = calc(a, al, ast, d, dl, dst, mid)
        if e == 0:
            note = ' It had no effect!'
        else:
            if randint(1, 16) == 1:
                dmg *= 2
                note = ' A critical hit!'
            dmg = max(1, dmg * randint(85, 100) // 100)
            if mine and 'POWER' in CHEATS:
                dmg = d[3]
            dmg = min(dmg, d[3])
            d[3] -= dmg
            if e > 4:
                note += " It's super effective!"
            elif e < 4:
                note += " It's not very effective..."
    fx = m[3]
    if m[2] == 0 or dmg > 0:
        if fx == 1:
            note += stage(dst, 0, -1, dn, 'ATK')
        elif fx == 2:
            note += stage(dst, 1, -1, dn, 'DEF')
        elif fx == 3:
            note += stage(ast, 0, 1, an, 'ATK')
        elif fx == 4:
            note += stage(ast, 1, 1, an, 'DEF')
        elif fx == 5:
            if a[3] < amx:
                a[3] = min(amx, a[3] + amx // 2)
                note += ' ' + an + ' regained HP!'
            else:
                note += ' But HP is already full!'
        elif fx == 6:
            a[3] = min(amx, a[3] + max(1, dmg // 2))
            note += ' ' + an + ' drained HP!'
        elif fx == 7:
            a[3] = max(0, a[3] - max(1, dmg // 4))
            note += ' ' + an + ' is hit by recoil!'
        elif fx == 8:
            note += stage(ast, 1, -1, an, 'DEF')
    foe_box(B[2])
    me_box(G, B[1])
    if note:
        C.say(note[1:])
    else:
        C.wait_ab()
def learn(p, lv):
    ls = C.LEARN[C.SPECIES[p[0]][10]]
    for i in range(0, len(ls), 2):
        mid = ls[i + 1]
        if ls[i] != lv or mid in p[4:8]:
            continue
        mv = C.MOVES[mid][0]
        if 0 in p[4:8]:
            p[4 + p[4:8].index(0)] = mid
            C.say(name(p) + ' learned ' + mv + '!')
            continue
        if C.ask(name(p) + ' wants to learn ' + mv + '. Forget a move for it?'):
            j = C.menu([C.MOVES[x][0] for x in p[4:8]], 100, 30, 200)
            if j >= 0:
                old = C.MOVES[p[4 + j]][0]
                p[4 + j] = mid
                C.say(name(p) + ' forgot ' + old + ' and learned ' + mv + '!')
                continue
        C.say(name(p) + ' did not learn ' + mv + '.')
def grow(G, p, gain):
    C.say(name(p) + ' gained ' + str(gain) + ' EXP!')
    p[2] = min(p[2] + gain, C.exp_at(100))
    while p[1] < 100 and p[2] >= C.exp_at(p[1] + 1):
        old = C.maxhp(p)
        p[1] += 1
        if p not in CAPPED:
            p[3] += C.maxhp(p) - old
        C.say(name(p) + ' grew to Lv ' + str(p[1]) + '!')
        learn(p, p[1])
def evolve_all(G):
    for p in G.party:
        s = C.SPECIES[p[0]]
        while s[6] >= 0 and p[1] >= s[7]:
            C.clear_bg()
            C.icon(160, 70, p[0])
            C.say('What? ' + s[0] + ' is evolving!')
            old = C.maxhp(p)
            p[0] = s[6]
            if p[3] > 0:
                p[3] += C.maxhp(p) - old
            C.clear_bg()
            C.icon(160, 70, p[0])
            C.say(s[0] + ' evolved into ' + C.SPECIES[p[0]][0] + '!')
            s = C.SPECIES[p[0]]
def pick_mon(G, why):
    C.plist(G.party, why)
    return C.pick_row(len(G.party), 0)
def use_on(G, i, fight):
    j = pick_mon(G, 'Use it on which one?')
    if j < 0:
        return False
    p = G.party[j]
    mx = bmax(G, p) if fight else C.maxhp(p)
    if i == 3:
        if p[3] > 0:
            C.say('It has no effect on ' + name(p) + '.')
            return False
        p[3] = mx // 2
        C.say(name(p) + ' was revived!')
    else:
        if p[3] == 0 or p[3] >= mx:
            C.say('It has no effect on ' + name(p) + '.')
            return False
        n = min(HEAL[i], mx - p[3])
        p[3] += n
        C.say(name(p) + ' regained ' + str(n) + ' HP!')
    G.bag[i] -= 1
    return True
def cap_item(G):
    v = C.num_pick('LEVEL CAP  (0 = OFF)', G.cap or 50, 0, 100, 10,
                   lambda n: 'Lv ' + str(n) if n else 'OFF')
    if v is None:
        return
    G.cap = v
    if v:
        C.say('LEVEL CAP set to Lv ' + str(v) + '. Stronger POKEMON will battle as Lv ' + str(v) + '.')
    else:
        C.say('LEVEL CAP is OFF. Your POKEMON battle at their real levels.')
def bag_menu(G, fight=0):
    while 1:
        rows = []
        ids = []
        for i in range(len(ITEMS)):
            if G.bag[i]:
                rows.append(ITEMS[i][0] + ' x' + str(G.bag[i]))
                ids.append(i)
        if G.capitem:
            rows.append('LEVEL CAP ' + ('Lv' + str(G.cap) if G.cap else 'OFF'))
            ids.append(-2)
        if not rows:
            C.say('Your BAG is empty.')
            return -1
        c = C.menu(rows, 40, 4, 240)
        if c < 0:
            return -1
        i = ids[c]
        if i == -2:
            if fight:
                C.say("You can't change the LEVEL CAP during a battle.")
                continue
            cap_item(G)
            return -2
        if i == 0:
            if not fight:
                C.say('There is no wild POKEMON to catch here.')
                continue
            return 0
        if use_on(G, i, fight):
            return i
        if fight:
            return -1
def first_alive(G):
    for i in range(len(G.party)):
        if G.party[i][3] > 0:
            return i
    return -1
def switch_in(G, B, forced):
    while 1:
        C.plist(G.party, 'Send out which one?')
        j = C.pick_row(len(G.party), 0)
        if j < 0:
            if forced:
                continue
            return False
        p = G.party[j]
        if p[3] == 0:
            C.say(name(p) + ' has no energy left to battle!')
        elif p is B[1]:
            C.say(name(p) + ' is already in battle!')
        else:
            B[1] = p
            B[3] = [0, 0]
            return True
def throw(G, B):
    G.bag[0] -= 1
    f = B[2]
    C.say('You threw a POKE BALL!', 0)
    sleep(0.5)
    mx = C.maxhp(f)
    rate = C.SPECIES[f[0]][9]
    if 'LUCKY' in CHEATS or randint(0, 3 * mx * 255 - 1) < rate * (3 * mx - 2 * f[3]):
        C.col(BG)
        C.rect(196, 4, 124, 80)
        C.col((220, 60, 50))
        C.circ(250, 52, 9)
        C.say('Gotcha! ' + name(f) + ' was caught!')
        if len(G.party) < 6:
            G.party.append(f)
        elif len(G.pc) < 50:
            G.pc.append(f)
            C.say(name(f) + ' was sent to the PC.')
        else:
            C.say('The PC is full! ' + name(f) + ' was released.')
        return True
    C.say('Oh no! It broke free!')
    return False
def wild(G, foe, cheats):
    global CHEATS
    CHEATS = cheats
    i = first_alive(G)
    if i < 0:
        return 'run'
    cap_in(G)
    B = [G, G.party[i], foe, [0, 0], [0, 0], 0]
    scene(G, None, foe)
    C.say('A wild ' + name(foe) + ' appeared!')
    scene(G, B[1], foe)
    C.say('Go! ' + name(B[1]) + '!')
    res = fight(G, B, 0)
    cap_out(G)
    return res
def trainer(G, title, team, prize, cheats, smart=0):
    global CHEATS
    CHEATS = cheats
    i = first_alive(G)
    if i < 0:
        return 'lose'
    cap_in(G)
    foes = [C.mk(sp, lv) for sp, lv in team]
    B = [G, G.party[i], foes[0], [0, 0], [0, 0], smart]
    res = 'win'
    for n in range(len(foes)):
        f = foes[n]
        B[2] = f
        B[4] = [0, 0]
        if n == 0:
            scene(G, None, f)
            C.say(title + ' wants to battle!')
        scene(G, B[1] if n else None, f)
        C.say(title + ' sent out ' + name(f) + '!')
        if n == 0:
            scene(G, B[1], f)
            C.say('Go! ' + name(B[1]) + '!')
        res = fight(G, B, 1)
        if res != 'win':
            break
        if B[1][3] == 0 and n + 1 < len(foes):
            if first_alive(G) < 0:
                C.say('You have no POKEMON left that can fight! You blacked out!')
                res = 'lose'
                break
            switch_in(G, B, 1)
    cap_out(G)
    if res == 'win':
        G.money = min(G.money + prize, 999999)
        C.say('You defeated ' + title + '!|You got $' + str(prize) + ' for winning!')
    return res
EXP_DIV = 3
def fight(G, B, tr):
    while 1:
        p = B[1]
        footer('What will ' + name(p) + ' do?')
        c = grid(('FIGHT', 'BAG', 'POKEMON', 'RUN'))
        acted = 0
        if c == 0:
            ms = [m for m in p[4:8] if m] or [1]
            k = grid([C.MOVES[m][0] for m in ms], 0,
                     lambda s: C.TYPES[C.MOVES[ms[s]][1]] + '  POWER ' +
                     (str(C.MOVES[ms[s]][2]) if C.MOVES[ms[s]][2] else '-'))
            if k < 0:
                continue
            attack(B, 1, ms[k])
            acted = 1
        elif c == 1:
            u = bag_menu(G, 1)
            scene(G, B[1], B[2])
            if u == 0:
                if tr:
                    C.say("You can't catch another trainer's POKEMON!")
                    continue
                if throw(G, B):
                    return 'caught'
                acted = 1
            elif u > 0:
                acted = 1
        elif c == 2:
            if switch_in(G, B, 0):
                scene(G, B[1], B[2])
                C.say('Go! ' + name(B[1]) + '!')
                acted = 1
            else:
                scene(G, B[1], B[2])
        elif c == 3:
            if tr:
                C.say("No running from a trainer battle!")
                continue
            C.say('Got away safely!')
            return 'run'
        else:
            continue
        if not acted:
            continue
        f = B[2]
        if f[3] == 0:
            C.say('Foe ' + name(f) + ' fainted!')
            gain = C.SPECIES[f[0]][8] * f[1] // EXP_DIV
            grow(G, B[1], gain * 3 // 2 if tr else gain)
            return 'win'
        if B[1][3] > 0:
            attack(B, 0, ai_move(B))
        if B[1][3] == 0 or (f[3] == 0):
            if f[3] == 0:
                C.say('Foe ' + name(f) + ' fainted!')
                return 'win'
            C.say(name(B[1]) + ' fainted!')
            if first_alive(G) < 0:
                C.say('You have no POKEMON left that can fight! You blacked out!')
                return 'lose'
            switch_in(G, B, 1)
            scene(G, B[1], f)
            C.say('Go! ' + name(B[1]) + '!')

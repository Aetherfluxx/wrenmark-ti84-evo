# WRCORE - part of WRENMARK for the TI-84 Evo (built by Dev/tools/build.py)
from ti_draw import fill_rect, set_color, draw_text, fill_circle
from ti_system import get_key
FX = 1
UP, DOWN, LEFT, RIGHT = 25, 34, 24, 26
ENTER, SECOND, CLEAR, MODE, DEL = 105, 21, 45, 22, 23
A_KEYS = (ENTER, SECOND)
B_KEYS = (CLEAR, DEL)
DIRS = {UP: (0, -1, 0), DOWN: (0, 1, 1), LEFT: (-1, 0, 2), RIGHT: (1, 0, 3)}
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREY = (120, 120, 120)
_c = None
def col(c):
    global _c
    if c is not _c:
        _c = c
        set_color(c[0], c[1], c[2])
def rect(x, y, w, h):
    fill_rect(x - FX, y - FX, w + FX, h + FX)
def circ(x, y, r):
    fill_circle(x, y, r)
def txt(x, top, s):
    draw_text(x, top + 17, s)
_last = 0
_lock = 0
def key(rep=0):
    global _last, _lock
    while 1:
        k = get_key(0)
        if k == 0:
            _last = 0
            _lock = 0
        elif _lock and k in DIRS:
            pass
        elif k != _last or (rep and k in DIRS):
            _last = k
            return k
def lock():
    global _lock
    _lock = 1
def wait_ab():
    while 1:
        k = key()
        if k in A_KEYS or k in B_KEYS:
            return k
def box(x, y, w, h):
    col(BLACK)
    rect(x, y, w, h)
    col(WHITE)
    rect(x + 2, y + 2, w - 4, h - 4)
def wrap(s, n=30):
    out = []
    for para in s.split('|'):
        line = ''
        for w in para.split(' '):
            if not line:
                line = w
            elif len(line) + 1 + len(w) <= n:
                line = line + ' ' + w
            else:
                out.append(line)
                line = w
        out.append(line)
    return out
BOX_Y = 146
def say(s, w=1):
    ls = wrap(s)
    i = 0
    while i < len(ls):
        box(0, BOX_Y, 320, 46)
        col(BLACK)
        txt(8, BOX_Y + 5, ls[i])
        if i + 1 < len(ls):
            txt(8, BOX_Y + 24, ls[i + 1])
        if i + 2 < len(ls):
            col(GREY)
            rect(306, BOX_Y + 36, 6, 4)
        elif not w:
            return
        wait_ab()
        i += 2
def menu(items, x, y, w, sel=0):
    n = len(items)
    box(x, y, w, n * 20 + 8)
    col(BLACK)
    for i in range(n):
        txt(x + 18, y + 4 + i * 20, items[i])
    while 1:
        col(BLACK)
        txt(x + 5, y + 4 + sel * 20, '>')
        k = key()
        if k in A_KEYS:
            return sel
        if k in B_KEYS:
            return -1
        if k == UP or k == DOWN:
            col(WHITE)
            rect(x + 4, y + 4 + sel * 20, 12, 18)
            sel = (sel + (1 if k == DOWN else -1)) % n
def ask(q):
    say(q, 0)
    return menu(('YES', 'NO'), 230, 96, 80) == 0
TYPES = ('FIRE', 'WATER', 'GRASS', 'NORMAL', 'ELECTRIC',
         'ICE', 'GROUND', 'FLYING', 'ROCK', 'PSYCHIC')
TCOL = ((230, 90, 40), (60, 120, 230), (70, 170, 70), (180, 170, 150),
        (240, 210, 40), (140, 210, 230), (190, 150, 80), (150, 160, 230),
        (150, 130, 100), (220, 90, 170))
CHART = ('hh211211h1'
         '2hh1112121'
         'h2h1112h21'
         '11111111h1'
         '12h1h10212'
         'hh211h2211'
         '21h1211021'
         '1121h111h1'
         '211112h212'
         '111211211h')
MOVES = (
    ('-', 3, 0, 0),
    ('BUMP', 3, 35, 0), ('SWIPE', 3, 50, 0), ('STAMPEDE', 3, 90, 7),
    ('SCOWL', 3, 0, 1), ('BRACE', 3, 0, 4), ('FOCUS', 3, 0, 3), ('DOZE', 3, 0, 5),
    ('CINDER', 0, 40, 0), ('FLAME LASH', 0, 70, 0), ('BLAZE BURST', 0, 110, 8),
    ('SPLASH SHOT', 1, 40, 0), ('TIDE SLAM', 1, 70, 0), ('RIPTIDE', 1, 105, 8),
    ('LEAF NICK', 2, 40, 0), ('VINE LASH', 2, 65, 0), ('SAP DRAIN', 2, 50, 6),
    ('BLOOM STORM', 2, 110, 8), ('SPORE CLOUD', 2, 0, 2),
    ('ZAP', 4, 40, 0), ('JOLT', 4, 70, 0), ('STORM BOLT', 4, 105, 8),
    ('STATIC FUZZ', 4, 0, 1),
    ('FROST NIP', 5, 45, 0), ('CHILL WIND', 5, 55, 1), ('GLACIER', 5, 100, 8),
    ('MUD FLING', 6, 35, 2), ('DIG STRIKE', 6, 70, 0), ('QUAKE', 6, 100, 8),
    ('BEAK JAB', 7, 40, 0), ('GUST WING', 7, 60, 0), ('SKY DIVE', 7, 90, 7),
    ('PEBBLE TOSS', 8, 40, 0), ('ROCK SLAM', 8, 75, 0), ('ROCKFALL', 8, 100, 8),
    ('STONE SKIN', 8, 0, 4),
    ('MIND POKE', 9, 45, 0), ('MIND WAVE', 9, 70, 0), ('PSI SURGE', 9, 100, 8),
    ('REVERIE', 9, 0, 5), ('MIND LEECH', 9, 55, 6),
)
SPECIES = (
    ('BURRLAMB', 2, -1, 50, 45, 55, 1, 16, 64, 45, 0),
    ('THISTRAM', 2, -1, 65, 60, 70, 2, 34, 142, 45, 0),
    ('BRIARHORN', 2, 8, 85, 80, 95, -1, 0, 236, 45, 0),
    ('SOOTKIT', 0, -1, 44, 58, 40, 4, 16, 64, 45, 1),
    ('EMBROCK', 0, -1, 58, 78, 55, 5, 34, 142, 45, 1),
    ('MAGMABROCK', 0, 6, 78, 105, 72, -1, 0, 236, 45, 1),
    ('WADLET', 1, -1, 48, 50, 48, 7, 16, 64, 45, 2),
    ('REEDWADER', 1, -1, 63, 68, 62, 8, 34, 142, 45, 2),
    ('TIDECRANE', 1, 7, 82, 90, 80, -1, 0, 236, 45, 2),
    ('PIPWICK', 3, 7, 40, 45, 35, 10, 18, 50, 255, 3),
    ('GUSTWING', 3, 7, 63, 70, 60, -1, 0, 140, 90, 3),
    ('NIBBIN', 3, -1, 35, 50, 35, 12, 20, 51, 255, 4),
    ('GNAWLORD', 3, -1, 60, 80, 60, -1, 0, 145, 90, 4),
    ('SPRIGG', 2, -1, 45, 45, 50, 14, 22, 60, 190, 5),
    ('HEDGEROOT', 2, 6, 70, 70, 80, -1, 0, 150, 75, 5),
    ('MOLEBY', 6, -1, 45, 55, 45, 16, 22, 62, 190, 6),
    ('DELVEMOLE', 6, -1, 70, 85, 70, -1, 0, 155, 75, 6),
    ('PUFFCAP', 2, 9, 50, 40, 50, 18, 26, 66, 190, 7),
    ('TOADSTULE', 2, 9, 75, 75, 80, -1, 0, 160, 75, 7),
    ('ZAPPUP', 4, -1, 45, 55, 40, 20, 26, 64, 190, 8),
    ('VOLTUSK', 4, -1, 70, 90, 70, -1, 0, 165, 75, 8),
    ('GLIDZAP', 4, 7, 60, 70, 60, -1, 0, 140, 120, 9),
    ('PEBBIT', 8, -1, 40, 55, 70, 23, 24, 60, 190, 10),
    ('BOULDOX', 8, -1, 70, 90, 110, -1, 0, 165, 75, 10),
    ('TUSKORE', 8, 6, 75, 85, 85, -1, 0, 155, 90, 11),
    ('SHELLK', 1, 8, 40, 55, 75, 26, 28, 66, 190, 12),
    ('CLAWSHELL', 1, 8, 65, 90, 105, -1, 0, 165, 75, 12),
    ('LILLOP', 1, 2, 50, 45, 50, 28, 30, 64, 190, 13),
    ('LILYFROND', 1, 2, 80, 75, 80, -1, 0, 160, 75, 13),
    ('WICKLE', 0, -1, 40, 60, 40, 30, 28, 62, 190, 14),
    ('PYREWICK', 0, -1, 65, 100, 60, -1, 0, 165, 75, 14),
    ('FROSTLET', 5, -1, 50, 60, 50, 32, 32, 66, 190, 15),
    ('RIMEFANG', 5, -1, 75, 100, 70, -1, 0, 170, 60, 15),
    ('SNOWISP', 5, -1, 40, 50, 50, 34, 30, 62, 190, 16),
    ('AURORWING', 5, 7, 70, 85, 75, -1, 0, 165, 75, 16),
    ('DREAMLET', 9, -1, 45, 50, 45, 36, 30, 66, 150, 17),
    ('SOMNOWL', 9, 7, 75, 85, 75, -1, 0, 170, 60, 17),
    ('MIRRIN', 9, -1, 45, 55, 50, 38, 32, 66, 150, 18),
    ('MIRRORIX', 9, -1, 70, 95, 80, -1, 0, 175, 60, 18),
)
LEARN = (
    (1, 1, 1, 5, 6, 14, 12, 16, 18, 15, 25, 18, 34, 33, 42, 17),
    (1, 1, 1, 4, 6, 8, 9, 26, 15, 2, 20, 9, 28, 6, 34, 27, 42, 10, 48, 28),
    (1, 1, 1, 4, 6, 11, 11, 29, 16, 12, 24, 5, 30, 23, 34, 30, 42, 13),
    (1, 1, 4, 29, 9, 4, 15, 30, 24, 2, 32, 31),
    (1, 1, 1, 4, 7, 2, 14, 6, 22, 7, 30, 3),
    (1, 1, 5, 14, 10, 26, 16, 16, 22, 27, 30, 15, 40, 17),
    (1, 1, 1, 26, 8, 5, 14, 27, 24, 2, 32, 28),
    (1, 14, 1, 18, 8, 36, 15, 16, 26, 37, 34, 40),
    (1, 1, 1, 19, 8, 22, 15, 2, 22, 20, 30, 6, 38, 21),
    (1, 19, 1, 29, 10, 22, 20, 30, 28, 20, 38, 31),
    (1, 1, 1, 35, 8, 32, 16, 26, 24, 33, 34, 34),
    (1, 32, 1, 26, 12, 35, 20, 27, 30, 33, 40, 28),
    (1, 11, 1, 35, 10, 32, 18, 12, 28, 33, 38, 13),
    (1, 11, 1, 14, 8, 16, 16, 12, 24, 15, 34, 39),
    (1, 8, 1, 4, 10, 6, 18, 9, 28, 2, 38, 10),
    (1, 1, 1, 23, 10, 4, 18, 24, 26, 2, 36, 25),
    (1, 23, 1, 29, 10, 24, 20, 30, 30, 5, 40, 25),
    (1, 36, 1, 7, 10, 4, 18, 40, 26, 37, 30, 29, 40, 38),
    (1, 36, 1, 6, 12, 2, 20, 37, 30, 39, 40, 38),
)
FEAT = (1, 9, 4, 4, 1, 16, 8, 32, 9, 4, 16, 2, 32, 32, 64, 1, 4, 4, 64)
STAGE = [0] * len(SPECIES)
for _i in range(len(SPECIES)):
    _e = SPECIES[_i][6]
    if _e >= 0:
        STAGE[_e] = STAGE[_i] + 1
def exp_at(lv):
    return lv * lv * lv * 4 // 5
def stat(sp, lv, i):
    b = SPECIES[sp][3 + i]
    v = 2 * b * lv // 100
    return v + lv + 10 if i == 0 else v + 5
def maxhp(p):
    return stat(p[0], p[1], 0)
def moves_at(sp, lv):
    ls = LEARN[SPECIES[sp][10]]
    out = []
    for i in range(0, len(ls), 2):
        if ls[i] <= lv and ls[i + 1] not in out:
            out.append(ls[i + 1])
    out = out[-4:]
    while len(out) < 4:
        out.append(0)
    return out
def mk(sp, lv):
    p = [sp, lv, exp_at(lv), 0] + moves_at(sp, lv)
    p[3] = maxhp(p)
    return p
def set_level(p, lv):
    p[1] = lv
    p[2] = exp_at(lv)
    p[3] = maxhp(p)
def eff(mt, sp):
    m = 4
    for t in (SPECIES[sp][1], SPECIES[sp][2]):
        if t >= 0:
            c = CHART[mt * 10 + t]
            if c == '2':
                m *= 2
            elif c == 'h':
                m //= 2
            elif c == '0':
                m = 0
    return m
def tname(sp):
    s = SPECIES[sp]
    return TYPES[s[1]] + ('/' + TYPES[s[2]] if s[2] >= 0 else '')
def icon(cx, cy, sp, r=0):
    s = SPECIES[sp]
    if not r:
        r = 14 + 5 * STAGE[sp]
    c1 = TCOL[s[1]]
    c2 = TCOL[s[2]] if s[2] >= 0 else (245, 240, 225)
    f = FEAT[s[10]]
    q = max(r // 3, 2)
    if f & 4:
        col(c2)
        circ(cx - r, cy, r // 2)
        circ(cx + r, cy, r // 2)
    if f & 8:
        col(c1)
        rect(cx + r // 2, cy + r // 4, r, max(r // 4, 2))
    if f & 32:
        col(c2)
        circ(cx, cy - r // 3, r * 5 // 6)
    col(c1)
    if f & 1:
        circ(cx - r * 2 // 3, cy - r * 3 // 4, q)
        circ(cx + r * 2 // 3, cy - r * 3 // 4, q)
    if f & 2 or STAGE[sp] == 2:
        col((240, 235, 210))
        rect(cx - r // 2, cy - r - q, 3, q + 2)
        rect(cx + r // 2 - 2, cy - r - q, 3, q + 2)
    if f & 16:
        col((90, 80, 70))
        for dx in (-q, 0, q):
            rect(cx + dx - 1, cy - r - q // 2, 3, q + 2)
    if f & 64:
        col((90, 80, 70))
        rect(cx - 1, cy - r - q, 3, q + 2)
        col((250, 170, 40))
        circ(cx, cy - r - q, max(q // 2, 2))
    col(c1)
    circ(cx, cy, r)
    col(c2)
    circ(cx, cy + r // 3, r // 2)
    e = max(r // 5, 2)
    col((255, 255, 255))
    circ(cx - r // 3, cy - r // 4, e)
    circ(cx + r // 3, cy - r // 4, e)
    col((20, 20, 20))
    rect(cx - r // 3 - 1, cy - r // 4 - 1, 2, 2)
    rect(cx + r // 3 - 1, cy - r // 4 - 1, 2, 2)
BG = (248, 248, 240)
BAR = (40, 40, 60)
def clear_bg():
    col(BG)
    rect(0, 0, 320, 210)
def footer(s):
    col(BAR)
    rect(0, 192, 320, 18)
    col(WHITE)
    txt(4, 193, s)
def hpbar(x, y, w, hp, mx):
    col((60, 60, 60))
    rect(x, y, w, 6)
    f = hp * (w - 2) // mx if mx else 0
    if f >= 2:
        if hp * 2 > mx:
            col((60, 190, 80))
        elif hp * 5 > mx:
            col((240, 190, 40))
        else:
            col((220, 60, 50))
        rect(x + 1, y + 1, f, 4)
def plist(party, tip):
    clear_bg()
    for i in range(len(party)):
        p = party[i]
        y = 2 + i * 32
        mx = maxhp(p)
        icon(30, y + 15, p[0], 9)
        col(BLACK)
        txt(48, y, SPECIES[p[0]][0])
        txt(200, y, 'Lv' + str(p[1]))
        txt(200, y + 14, str(p[3]) + '/' + str(mx))
        hpbar(48, y + 20, 140, p[3], mx)
    footer(tip)
def pick_row(n, sel):
    while 1:
        col(BLACK)
        txt(2, 8 + sel * 32, '>')
        k = key()
        if k in A_KEYS:
            return sel
        if k in B_KEYS:
            return -1
        if k == UP or k == DOWN:
            col(BG)
            rect(2, 8 + sel * 32, 12, 18)
            sel = (sel + (1 if k == DOWN else -1)) % n
def summary(p, cap=0):
    sp = p[0]
    s = SPECIES[sp]
    clear_bg()
    icon(60, 62, sp)
    col(BLACK)
    txt(128, 4, s[0])
    txt(128, 24, tname(sp))
    txt(128, 44, 'Lv ' + str(p[1]) + (' CAP ' + str(cap) if cap and p[1] > cap else ''))
    mx = maxhp(p)
    txt(128, 64, 'HP ' + str(p[3]) + '/' + str(mx))
    txt(128, 84, 'ATK ' + str(stat(sp, p[1], 1)) +
          '  DEF ' + str(stat(sp, p[1], 2)))
    if p[1] < 100:
        txt(128, 104, 'NEXT LV ' + str(max(exp_at(p[1] + 1) - p[2], 0)) + ' EXP')
    else:
        txt(128, 104, 'MAX LEVEL')
    if s[6] >= 0:
        txt(10, 104, 'EVO Lv' + str(s[7]))
    col(BAR)
    rect(0, 126, 320, 2)
    for i in range(4):
        m = MOVES[p[4 + i]]
        col(BLACK)
        if p[4 + i]:
            pw = str(m[2]) if m[2] else '-'
            txt(10, 130 + i * 19, m[0] + ' ' * (13 - len(m[0])) +
                  TYPES[m[1]] + ' ' * (9 - len(TYPES[m[1]])) + pw)
        else:
            txt(10, 130 + i * 19, '-')
    wait_ab()
def party_menu(G):
    if not G.party:
        say('You have no POKEMON yet.')
        return
    sel = 0
    while 1:
        plist(G.party, 'ENTER choose   CLEAR back')
        sel = pick_row(len(G.party), sel)
        if sel < 0:
            return
        c = menu(('SUMMARY', 'SWITCH', 'CANCEL'), 196, 96, 120)
        if c == 0:
            summary(G.party[sel], G.cap)
        elif c == 1:
            plist(G.party, 'Move it where?')
            j = pick_row(len(G.party), sel)
            if j >= 0:
                G.party[sel], G.party[j] = G.party[j], G.party[sel]
                sel = j
def starter_screen(opts):
    col(BG)
    rect(0, 0, 320, 146)
    for i in range(3):
        cx = 60 + i * 100
        sp = opts[i]
        icon(cx, 50, sp)
        col(BLACK)
        n = SPECIES[sp][0]
        txt(cx - len(n) * 5, 82, n)
        t = TYPES[SPECIES[sp][1]]
        txt(cx - len(t) * 5, 102, t)
    say('PROF. LINDEN: Which one will be your partner?', 0)
def choose_starter():
    opts = (0, 3, 6)
    sel = 0
    starter_screen(opts)
    while 1:
        col(BLACK)
        rect(30 + sel * 100, 128, 60, 4)
        k = key()
        if k in B_KEYS:
            return -1
        if k in A_KEYS:
            sp = opts[sel]
            if ask('So you want ' + SPECIES[sp][0] + ', the ' +
                     TYPES[SPECIES[sp][1]] + ' type?'):
                return sp
            starter_screen(opts)
        if k == LEFT or k == RIGHT:
            col(BG)
            rect(30 + sel * 100, 128, 60, 4)
            sel = (sel + (1 if k == RIGHT else -1)) % 3
def pc_show(G):
    return lambda i: '#' + str(i + 1) + ' ' + SPECIES[G.pc[i][0]][0] + ' Lv' + str(G.pc[i][1])
def pc_menu(G):
    while 1:
        clear_bg()
        footer('PC   ' + str(len(G.pc)) + ' of 50 stored')
        c = menu(('WITHDRAW', 'DEPOSIT', 'LOG OFF'), 80, 40, 160)
        if c == 0:
            if not G.pc:
                say('There are no POKEMON stored in the PC.')
            elif len(G.party) >= 6:
                say('Your party is full. Deposit one first.')
            else:
                i = num_pick('WITHDRAW WHICH ONE?', 0, 0, len(G.pc) - 1, 5, pc_show(G), 1)
                if i is not None:
                    p = G.pc.pop(i)
                    G.party.append(p)
                    say(SPECIES[p[0]][0] + ' joined your party.')
        elif c == 1:
            if len(G.party) <= 1:
                say("You can't deposit your last POKEMON.")
            elif len(G.pc) >= 50:
                say('The PC is full.')
            else:
                plist(G.party, 'Deposit which one?')
                j = pick_row(len(G.party), 0)
                if j >= 0:
                    p = G.party.pop(j)
                    G.pc.append(p)
                    say(SPECIES[p[0]][0] + ' was stored in the PC.')
        else:
            return
def num_pick(label, v, lo, hi, big, show, wrap=0, small=1):
    while 1:
        box(4, 66, 312, 76)
        col(BLACK)
        txt(14, 72, label)
        txt(14, 94, '< ' + show(v) + ' >')
        col(GREY)
        txt(14, 116, 'L/R ' + str(small) + '  U/D ' + str(big) + '  ENTER ok')
        k = key(1)
        if k in A_KEYS:
            return v
        if k in B_KEYS:
            return None
        d = {LEFT: -small, RIGHT: small, UP: big, DOWN: -big}.get(k, 0)
        v += d
        if wrap:
            v = lo + (v - lo) % (hi - lo + 1)
        else:
            v = min(max(v, lo), hi)
def sp_show(v):
    return SPECIES[v][0] + ' ' + tname(v)
def mv_show(v):
    m = MOVES[v]
    return m[0] + ' ' + TYPES[m[1]] + ' ' + str(m[2]) if v else '(none)'
def edit_mon(G, i):
    p = G.party[i]
    while 1:
        summary_bg(p)
        c = menu(('SPECIES', 'LEVEL', 'MOVES', 'AUTO MOVES', 'FULL HEAL',
                    'REMOVE', 'BACK'), 150, 4, 166)
        if c == 0:
            v = num_pick('SPECIES', p[0], 0, len(SPECIES) - 1, 10, sp_show, 1)
            if v is not None:
                p[0] = v
                p[3] = maxhp(p)
        elif c == 1:
            v = num_pick('LEVEL', p[1], 1, 100, 10, str)
            if v is not None:
                set_level(p, v)
        elif c == 2:
            while 1:
                summary_bg(p)
                names = [mv_show(m) if m else '(empty)' for m in p[4:8]]
                j = menu(names, 4, 4, 312)
                if j < 0:
                    break
                v = num_pick('MOVE ' + str(j + 1), p[4 + j], 0, len(MOVES) - 1, 10, mv_show, 1)
                if v is not None:
                    p[4 + j] = v
        elif c == 3:
            p[4:8] = moves_at(p[0], p[1])
        elif c == 4:
            p[3] = maxhp(p)
        elif c == 5:
            if len(G.party) > 1:
                G.party.pop(i)
                return
            say('You must keep at least one POKEMON.')
        else:
            return
def summary_bg(p):
    clear_bg()
    icon(60, 62, p[0])
    col(BLACK)
    txt(10, 104, SPECIES[p[0]][0])
    txt(10, 124, 'Lv ' + str(p[1]))
    footer('EDITOR')
def editor(G):
    while 1:
        clear_bg()
        footer('EDITOR  $' + str(G.money) + '  BADGES ' + str(G.badges))
        c = menu(('EDIT POKEMON', 'ADD POKEMON', 'HEAL ALL', 'MONEY',
                    'BADGES', 'MAX ITEMS', 'DONE'), 60, 8, 200)
        if c == 0:
            if not G.party:
                say('Your party is empty. Use ADD POKEMON.')
                continue
            plist(G.party, 'Edit which one?')
            i = pick_row(len(G.party), 0)
            if i >= 0:
                edit_mon(G, i)
        elif c == 1:
            if len(G.party) >= 6:
                say('Your party is full (6).')
                continue
            sp = num_pick('ADD WHICH POKEMON?', 0, 0, len(SPECIES) - 1, 10, sp_show, 1)
            if sp is None:
                continue
            lv = num_pick('AT WHAT LEVEL?', 5, 1, 100, 10, str)
            if lv is not None:
                G.party.append(mk(sp, lv))
        elif c == 2:
            for p in G.party:
                p[3] = maxhp(p)
            say('All POKEMON healed.')
        elif c == 3:
            v = num_pick('MONEY', G.money, 0, 999999, 10000, str, 0, 100)
            if v is not None:
                G.money = v
        elif c == 4:
            v = num_pick('BADGES', G.badges, 0, 4, 1, str)
            if v is not None:
                G.badges = v
                G.gyms = (1 << v) - 1
        elif c == 5:
            for i in range(len(G.bag)):
                G.bag[i] = 99
            say('Every item set to 99.')
        else:
            return

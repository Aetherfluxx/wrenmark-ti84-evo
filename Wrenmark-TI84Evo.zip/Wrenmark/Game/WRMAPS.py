# WRMAPS - part of WRENMARK for the TI-84 Evo (built by Dev/tools/build.py)
try:
    import WRCORE as C
except ImportError:
    try:
        import wrcore as C
    except ImportError:
        print('WRENMARK needs WRCORE.py on the calculator too.')
        raise
MAPS = (
('MOSSBROOK',
 'TTTTTTTTT..TTTTTTTTT'
 'T,,,,,,,,.T,,,,,,,,T'
 'T,rrr,,,,..,,,,rrr,T'
 'T,WDW,,,,..,,,,WDW,T'
 'T,,.,,,,,..,,,,,.,,T'
 'T,,..............,,T'
 'T,,,,,,,,..,,,,,,,,T'
 'T,f,,,rrrrr,,,S,,f,T'
 'T,,,,,WWLWW,,,,,,,,T'
 'T,,,,,,,.,,,,,,,,,,T'
 'T~~~~~,,,,,,,,~~~~~T'
 'TTTTTTTTTTTTTTTTTTTT',
 (1, -1, -1, -1), (),
 ((9, 1, 2, -1, 1, 'Wild POKEMON live in tall grass! See PROF. LINDEN first.'),
  (3, 3, 6, 0, 0, ''),
  (16, 3, 5, 0, 0, "The PROF's lab is the big building to the south."),
  (8, 8, 7, 0, 0, ''),
  (14, 7, 1, 0, 0, 'MOSSBROOK|Where journeys sprout.'),
  (12, 5, 0, 0, 1, 'They say there are 4 GYMS in WRENMARK!')),
 -1),
('ROUTE 1',
 'TTTTTTTTT..TTTTTTTTT'
 'T;;;;,,,,..,,,,TTTTT'
 'T;;;;,,,,..,,,,,,,,T'
 'T;;;;,,TT..,,;;;;,,T'
 'T,,,,,,TT..,,;;;;,,T'
 'T,,S,,,,,..,,;;;;,,T'
 'TTTTT,,,,..,,,,,,,,T'
 'T;;;;;,,,..,,,TTTTTT'
 'T;;;;;,,,..,,,,,,,,T'
 'T,,,,,,,,..,,,;;;;,T'
 'TTTTT,,,,..,,,;;;;,T'
 'TTTTTTTTT..TTTTTTTTT',
 (2, 0, -1, -1), (),
 ((3, 5, 1, 0, 0, 'ROUTE 1|MOSSBROOK - PEBBLEFIELD'),
  (11, 2, 0, 0, 1, 'Step into tall grass and wild POKEMON may appear.'),
  (6, 8, 3, 0, 3, "You're new here? Let's see what you've got!")),
 0),
('PEBBLEFIELD',
 'TTTTTTTTTTTTTTTTTTTT'
 'T,,,,,,,,,,,,,,,,,,T'
 'T,RRRR,,,,,,BBBB,,,T'
 'T,WPWW,,,,,,WMWW,,,T'
 'T,,.,,,,,,,,,.,,,,,T'
 'T,,...............,.'
 'T,,,,,,,,..,,,,,,,,.'
 'T,rrr,,,,..,,,rrr,,T'
 'T,WDW,,S,..,,,WDW,,T'
 'T,,,,,,,,..,,,,,,,,T'
 'T,f,,,,,,..,,,,,f,,T'
 'TTTTTTTTT..TTTTTTTTT',
 (-1, 1, -1, 3), (),
 ((7, 8, 1, 0, 0, 'PEBBLEFIELD|A quiet farming town.'),
  (3, 8, 5, 0, 0, 'My kid wants to be a GYM LEADER someday.'),
  (15, 8, 5, 0, 0, 'Red roofs heal POKEMON. Blue roofs sell supplies.'),
  (6, 6, 0, 0, 1, 'CRAGMOOR is east, through BRIARWOOD.')),
 -1),
('ROUTE 2',
 'TTTTTTTTTTTTTTTTTTTT'
 'T;;;TTT,,,,TTT;;;;TT'
 'T;;;TTT,TT,TTT;;;;TT'
 'T,,,,,,,TT,,,,,,,,TT'
 'TTTT,TT,TT,TTTT,TTTT'
 '.,,,,TT,,,,;;;;,,,,.'
 '.,,,,TT,,,,;;;;,,,,.'
 'TTTT,TTTTT,TTTT,TTTT'
 'T;;;,,,,,,,,,,,,;;;T'
 'T;;;TTTT,TT,TTTT;;;T'
 'T;;;;;,,,TT,,,;;;;;T'
 'TTTTTTTTTTTTTTTTTTTT',
 (-1, -1, 2, 4), (),
 ((7, 3, 3, 1, 1, 'The woods are full of POKEMON. Battle!'),
  (15, 8, 3, 2, 2, "Don't sneak past me!")),
 1),
('CRAGMOOR',
 'TTTTTTTTT..TTTTTTTTT'
 'T########.#########T'
 'T,,,,,,,,..,,,,,,,,T'
 'T,ggggg,,..,,RRRR,,T'
 'T,ggggg,,..,,WPWW,,T'
 '.,WWGWW,,..,,,.,,,,T'
 '.,,,.,,,,......,,,,T'
 'T,,,,,,,,..,,,,,,,,T'
 'T,BBBB,,,..,,rrr,S,T'
 'T,WMWW,,,..,,WDW,,,T'
 'T,,.,,,,,..,,,,,,,,T'
 'TTTTTTTTTTTTTTTTTTTT',
 (5, -1, 3, -1), ((4, 5, 21, 9, 9),),
 ((9, 1, 2, 1, 1, 'The cave north is dangerous. Come back with a BADGE.'),
  (17, 8, 1, 0, 0, 'CRAGMOOR GYM|LEADER TAMSIN - ROCK'),
  (14, 9, 5, 0, 0, 'ROCK POKEMON hate WATER and GRASS.')),
 -1),
('ROUTE 3',
 'TTTTTTTTTTTTTTTTTTTT'
 'T#######O###########'
 'T#,,,,,,.,,,,,,;;;;T'
 'T#,;;;;,.,,,,,,;;;;T'
 'T#,;;;;,.,####,,,,,T'
 'T,,,,,,,.,####,,S,,T'
 'T,,,,,....,,,,,,,,,T'
 'T;;;;,,,,.,,,;;;;;,T'
 'T;;;;,TT,.,,,;;;;;,T'
 'T,,,,,TT,..,,,,,,,,T'
 'TTTT,,,,,..,,,TTTTTT'
 'TTTTTTTTT..TTTTTTTTT',
 (-1, 4, -1, -1), ((8, 1, 6, 7, 10),),
 ((16, 5, 1, 0, 0, 'ROUTE 3|DUSKHOLLOW CAVE ahead'),
  (4, 6, 3, 3, 3, 'I train in these hills every day!'),
  (12, 7, 3, 4, 1, 'Hey! Eyes on me, kid!')),
 2),
('DUSKHOLLOW CAVE',
 'kkkkkkkkkkkkkkkkkkkk'
 'kkkkkkkkkkkXkkkkkkkk'
 'kcccccckkkkcckkkkkkk'
 'kcckkkcccccccckccckk'
 'kcckkkkkkkkkkcccckck'
 'kccccccckkkkkkkkkcck'
 'kkkkkkkcccccccckkcck'
 'kcccckkkkkkkkcccccck'
 'kcckccccccckkckkkkkk'
 'kcckkkkkkkccccccccck'
 'kcccccccXkkkkkkkkkkk'
 'kkkkkkkkkkkkkkkkkkkk',
 (-1, -1, -1, -1), ((8, 10, 5, 8, 2), (11, 1, 7, 4, 10)),
 ((16, 7, 3, 5, 2, 'Rocks, rocks, rocks! Battle me!'),),
 3),
('THISTLEDOWN',
 'TTTTTTTTTTTTTTTTTTTT'
 'T,,,,,,,,,,,,,,,,,,T'
 'T,rrr,,,,,,,RRRR,,,T'
 'T,WDW,,,,,,,WPWW,,,T'
 'T,,,,,,,,,,,,.,,,,,T'
 'T,,,..............,.'
 'T,f,.,,,,,,,,,,,,,,.'
 'T,,,.,,,rrr,,,S,,,,T'
 'T,,,.,,,WDW,,,,,,,,T'
 'T##,.,,,,,,,,,,,,,,T'
 'T##O.,,,,,,,,,,,f,,T'
 'TTTTTTTTTTTTTTTTTTTT',
 (-1, -1, -1, 8), ((3, 10, 6, 11, 2),),
 ((14, 7, 1, 0, 0, 'THISTLEDOWN|Gateway to the east.'),
  (3, 3, 5, 0, 0, 'SPARKFORD lies east. Its GYM uses ELECTRIC types.'),
  (9, 8, 5, 0, 0, 'GROUND POKEMON shrug off ELECTRIC attacks.'),
  (8, 5, 0, 0, 1, 'No shop here, sorry. Try SPARKFORD.')),
 -1),
('ROUTE 4',
 'TTTTTTTTTTTTTTTTTTTT'
 'T;;;;;,,,,,,~~~~,,,T'
 'T;;;;;,,,,,~~~~~~,,T'
 'T,,,,,,,TT,~~~~~~,,T'
 'T,,S,,,,TT,,~~~~,,,T'
 '.,,,,,,,,,,,,,,,,,,.'
 '.,,,,;;;;;;,,,,,,,,.'
 'TTT,,;;;;;;,,TTT,,,T'
 'T,,,,;;;;;;,,TTT;;;T'
 'T,TT,,,,,,,,,,,,;;;T'
 'T,TT,,,,,,TTTT,,;;;T'
 'TTTTTTTTTTTTTTTTTTTT',
 (-1, -1, 7, 9), (),
 ((3, 4, 1, 0, 0, 'ROUTE 4|THISTLEDOWN - SPARKFORD'),
  (7, 6, 3, 6, 3, 'My POKEMON are charged up!'),
  (11, 4, 3, 7, 1, 'You look strong. Prove it!')),
 4),
('SPARKFORD',
 'TTTTTTTTT..TTTTTTTTT'
 'T,,,,,,,,..,,,,,,,,T'
 'T,RRRR,,,..,,ggggg,T'
 'T,WPWW,,,..,,ggggg,T'
 'T,,.,,,,,..,,WWGWW,T'
 '.,,.............,,,T'
 '.,,,,,,,,..,,,,,,,,T'
 'T,BBBB,,,..,,,rrr,,T'
 'T,WMWW,,S..,,,WDW,,T'
 'T,,.,,,,,..,,,,,,,,T'
 'T,,,,,f,,..,,,,f,,,T'
 'TTTTTTTTTTTTTTTTTTTT',
 (10, -1, 8, -1), ((15, 4, 22, 9, 9),),
 ((8, 8, 1, 0, 0, 'SPARKFORD GYM|LEADER EZRA - ELECTRIC'),
  (15, 8, 5, 0, 0, "EZRA's BADGE lets your POKEMON SURF on water.")),
 -1),
('ROUTE 5',
 'TTTTTTTTT..TTTTTTTTT'
 'T,,,,,,,,..,,,,,,,,T'
 'T~~~~~~~~~~~~~~~~~~T'
 'T~~~~~~~~~~~~~~~~~~T'
 'T~~~,,;;~~~~~~~~~~~T'
 'T~~~,,;;~~~~~##~~~~T'
 'T~~~~~~~~~~~~##~~~~T'
 'T~~~~~~~~~~~~~~~~~~T'
 'T~~~~~~~~~~~~~~~~~~T'
 'T,,,,~~~~~~~~~~,,,,T'
 'T,S,,,,,,..,,,,,;;,T'
 'TTTTTTTTT..TTTTTTTTT',
 (11, 9, -1, -1), (),
 ((2, 10, 1, 0, 0, 'ROUTE 5|Need SURF to cross the lake.'),
  (5, 4, 3, 8, 1, 'Nobody reaches my island without a fight!')),
 5),
('LAKEMERE',
 'TTTTTTTTTTTTTTTTTTTT'
 'T~~~~~~,,,,,,~~~~~~T'
 'T~~,RRRR,,,BBBB,~~~T'
 'T~~,WPWW,,,WMWW,~~~T'
 'T,,,,.,,,,,,.,,,,,,T'
 '.,,,,...........,,,T'
 '.,,,,,,,,..,,,,,,,,T'
 'T,rrr,,,,..,,,rrr,,T'
 'T,WDW,,,S..,,,WDW,,T'
 'T~~,,,,,,..,,,,,,~~T'
 'T~~~~,,,,..,,,,~~~~T'
 'TTTTTTTTT..TTTTTTTTT',
 (-1, 10, 12, -1), (),
 ((8, 8, 1, 0, 0, 'LAKEMERE|Calm waters, kind hearts.'),
  (3, 8, 5, 0, 0, 'GALECREST is west, up in the windy hills.'),
  (15, 8, 5, 0, 0, 'FLYING POKEMON fear ELECTRIC, ICE and ROCK.')),
 -1),
('ROUTE 6',
 'TTTTTTTTTTTTTTTTTTTT'
 'T;;;;;;,,,####;;;;;T'
 'T;;;;;;,,,####;;;;;T'
 'T,,,,,,,,,,,,,,,,,,T'
 'T,####,,,;;;;,,###,T'
 '.,####,,,;;;;,,###,.'
 '.,,,,,,,,;;;;,,,,,,.'
 'T,,,,,###,,,,,,,,,,T'
 'T;;;,,###,,S,,;;;;,T'
 'T;;;,,,,,,,,,,;;;;,T'
 'T;;;,,TTTT,,,,TTTTTT'
 'TTTTTTTTTTTTTTTTTTTT',
 (-1, -1, 13, 11), (),
 ((11, 8, 1, 0, 0, 'ROUTE 6|GALECREST - LAKEMERE'),
  (8, 3, 3, 9, 1, 'The wind up here makes POKEMON tough!'),
  (16, 6, 3, 10, 2, "You won't pass me easily!")),
 6),
('GALECREST',
 'TTTTTTTTT..TTTTTTTTT'
 'T########.#########T'
 'T,,,,,,,,..,,,,,,,,T'
 'T,ggggg,,..,,RRRR,,T'
 'T,ggggg,,..,,WPWW,,T'
 'T,WWGWW,,..,,,.,,,,.'
 'T,,,.,,,,.........,.'
 'T,,,,,,,,..,,,,,,,,T'
 'T,BBBB,,,..,,rrr,S,T'
 'T,WMWW,,,..,,WDW,,,T'
 'T,,.,,,,,..,,,,,,,,T'
 'TTTTTTTTTTTTTTTTTTTT',
 (14, -1, -1, 12), ((4, 5, 23, 9, 9),),
 ((9, 1, 2, 3, 1, 'The north road is closed until you hold 3 BADGES.'),
  (17, 8, 1, 0, 0, 'GALECREST GYM|LEADER CORVIN - FLYING'),
  (14, 9, 5, 0, 0, 'Past the north road is icy FROSTFEN.')),
 -1),
('ROUTE 7',
 'TTTTTTTTT..TTTTTTTTT'
 'T;;;;,,,,..,,,,;;;;T'
 'T;;;;,TTT..TTT,;;;;T'
 'T,,,,,TTT..TTT,,,,,T'
 'T,###,,,,..,,,,###,T'
 'T,###,;;;;;;;;,###,T'
 'T,,,,,;;;;;;;;,,,,,T'
 'T,,S,,,,,..,,,,,,,,T'
 'TTTTT,,,,..,,,,TTTTT'
 'T;;;;,,,,..,,,,;;;;T'
 'T;;;;,,,,..,,,,;;;;T'
 'TTTTTTTTT..TTTTTTTTT',
 (15, 13, -1, -1), (),
 ((3, 7, 1, 0, 0, 'ROUTE 7|Cold winds blow from the north.'),
  (5, 3, 3, 11, 3, 'Brr! A battle will warm us up!'),
  (14, 9, 3, 12, 2, 'My POKEMON love the cold.')),
 7),
('FROSTFEN',
 'TTTTTTTTTTTTTTTTTTTT'
 'T~~~~,,,,,,,,,,,,,,T'
 'T~~~~,RRRR,,BBBB,,,T'
 'T~~~,,WPWW,,WMWW,,,T'
 'T~~,,,,.,,,,,.,,,,,T'
 'T,,,,,..........,,,.'
 'T,rrr,,,,..,,,,,,,,.'
 'T,WDW,,,,..,,,rrr,,T'
 'T,,,,,,S,..,,,WDW,,T'
 'T,f,,,,,,..,,,,,,,,T'
 'T,,,,,,,,..,,,,,f,,T'
 'TTTTTTTTT..TTTTTTTTT',
 (-1, 14, -1, 16), (),
 ((7, 8, 1, 0, 0, 'FROSTFEN|Warm hearts, cold toes.'),
  (3, 7, 5, 0, 0, 'STARHAVEN is east across the river. Its GYM is PSYCHIC.'),
  (15, 8, 5, 0, 0, 'PSYCHIC POKEMON fear ELECTRIC and ROCK moves.')),
 -1),
('ROUTE 8',
 'TTTTTTTTTTTTTTTTTTTT'
 'T;;;;,,,,~~~,,,;;;;T'
 'T;;;;,,,,~~~,,,;;;;T'
 'T,,,,,,,,~~~,,,,,,,T'
 'T,TT,,,,,~~~,,,,TT,T'
 '.,TT,,,,,~~~,,,,TT,.'
 '.,,,,,,,,~~~,,,,,,,.'
 'T,,S,;;;,~~~,;;;,,,T'
 'T,,,,;;;,~~~,;;;,,,T'
 'T;;;,,,,,~~~,,,,;;;T'
 'T;;;,,,,,~~~,,,,;;;T'
 'TTTTTTTTTTTTTTTTTTTT',
 (-1, -1, 15, 17), (),
 ((3, 7, 1, 0, 0, 'ROUTE 8|FROSTFEN - STARHAVEN'),
  (13, 3, 3, 13, 1, 'Surfers beware: I guard this bank!'),
  (6, 9, 3, 14, 0, 'My team is ready for anything.')),
 8),
('STARHAVEN',
 'TTTTTTTTT..TTTTTTTTT'
 'T,,,,,,,,..,,,,,,,,T'
 'T,RRRR,,,..,,ggggg,T'
 'T,WPWW,,,..,,ggggg,T'
 'T,,.,,,,,..,,WWGWW,T'
 '.,,.............,,,T'
 '.,,,,,,,,..,,,,,,,,T'
 'T,BBBB,,,..,,,rrr,,T'
 'T,WMWW,,S..,,,WDW,,T'
 'T,,.,,,,,..,,,,,,,,T'
 'T,f,,,f,,..,,,f,,f,T'
 'TTTTTTTTTTTTTTTTTTTT',
 (18, -1, 16, -1), ((15, 4, 24, 9, 9),),
 ((8, 8, 1, 0, 0, 'STARHAVEN GYM|LEADER ORLA - PSYCHIC'),
  (15, 8, 5, 0, 0, 'North is CROWN GATE, the road to the LEAGUE.')),
 -1),
('CROWN GATE',
 '#########..#########'
 '#########.##########'
 'T,,,,,,,,..,,,,,,,,T'
 'T,RRRR,,,..,,,BBBB,T'
 'T,WPWW,,,..,,,WMWW,T'
 'T,,.,,,,,..,,,,.,,,T'
 'T,,.............,,,T'
 'T,,,,,,,,..,,,,,,,,T'
 'T,f,,,S,,..,,,,,,f,T'
 'T,,,,,,,,..,,,,,,,,T'
 'T,,,,,,,,..,,,,,,,,T'
 'TTTTTTTTT..TTTTTTTTT',
 (19, 17, -1, -1), (),
 ((9, 1, 2, 4, 1, 'Only trainers with all 4 BADGES may pass.'),
  (6, 8, 1, 0, 0, 'CROWN GATE|SUMMIT PATH and the LEAGUE lie north.')),
 -1),
('SUMMIT PATH',
 '#########cc#########'
 '#ccccccc#ccccccccc##'
 '#c#####c#cc#c####c##'
 '#c#ccccc####c#ccccc#'
 '#c#c##########c###c#'
 '#ccc#cccccccc#cc#cc#'
 '###c#c######c##c#c##'
 '#ccc#cccc##cc#cc#cc#'
 '#c######c##c##c##c##'
 '#ccccccc#cccccc#ccc#'
 '#######ccccc####ccc#'
 '#########cc#########',
 (20, 18, -1, -1), (),
 ((3, 7, 3, 15, 3, 'Only the best reach the top!'),
  (18, 3, 3, 16, 2, 'This is the final test before the LEAGUE.')),
 9),
('CROWN PLATEAU',
 'TTTTTTTTTTTTTTTTTTTT'
 'T,,,,,ggggggggg,,,,T'
 'T,,,,,ggggggggg,,,,T'
 'T,,,,,WWWWGWWWW,,,,T'
 'T,f,,,,,,,.,,,,,,f,T'
 'T,,,,,,,,,.,,,,,,,,T'
 'T,RRRR,,,,.,,,BBBB,T'
 'T,WPWW,,,,.,,,WMWW,T'
 'T,,.,,,,,,.,,,,.,,,T'
 'T,,.......,,,,,,,,,T'
 'T,,,,,,,,..,,,,,,,,T'
 'TTTTTTTTT..TTTTTTTTT',
 (-1, 19, -1, -1), ((10, 3, 25, 8, 10),),
 ((12, 9, 0, 0, 1, 'The ELITE FOUR wait inside. Heal up first!'),),
 -1),
('CRAGMOOR GYM',
 'KKKKKKKKKKKKKKKKKKKK'
 'KFFFFFFFFFFFFFFFFFFK'
 'KFFFFFFFFFFFFFFFFFFK'
 'KF######FFF#######FK'
 'KFFFFFF#FFF#FFFFFFFK'
 'KFFFFFF#FFF#FFFFFFFK'
 'KF####F#FFF#F#####FK'
 'KFFFFFFFFFFFFFFFFFFK'
 'KFFFFFFFFFFFFFFFFFFK'
 'KFFFFFFFFFFFFFFFFFFK'
 'KFFFFFFFFXFFFFFFFFFK'
 'KKKKKKKKKKKKKKKKKKKK',
 (-1, -1, -1, -1), ((9, 10, 4, 4, 6),),
 ((9, 1, 4, 0, 1, 'I am TAMSIN. My ROCK team never cracks!'),
  (9, 5, 3, 17, 1, 'Get past me before you face TAMSIN!')),
 -1),
('SPARKFORD GYM',
 'KKKKKKKKKKKKKKKKKKKK'
 'KFFFFFFFFFFFFFFFFFFK'
 'KFFFFFFFFFFFFFFFFFFK'
 'KKKKKKKKKKKKKKKKKFFK'
 'KFFFFFFFFFFFFFFFFFFK'
 'KFFFFFFFFFFFFFFFFFFK'
 'KFFKKKKKKKKKKKKKKKKK'
 'KFFFFFFFFFFFFFFFFFFK'
 'KFFFFFFFFFFFFFFFFFFK'
 'KFFFFFFFFFFFFFFFFFFK'
 'KFFFFFFFFXFFFFFFFFFK'
 'KKKKKKKKKKKKKKKKKKKK',
 (-1, -1, -1, -1), ((9, 10, 9, 15, 5),),
 ((9, 1, 4, 1, 1, "I'm EZRA! Let's see if you can handle the charge!"),
  (14, 7, 3, 18, 2, 'Zap! You walked right into me!'),
  (5, 4, 3, 19, 3, 'EZRA is the brightest spark around!')),
 -1),
('GALECREST GYM',
 'KKKKKKKKKKKKKKKKKKKK'
 'KFFFFFFFFFFFFFFFFFFK'
 'KFFFFFFFFFFFFFFFFFFK'
 'KFFKKKKKKKKKKKKKKKKK'
 'KFFFFFFFFFFFFFFFFFFK'
 'KKKKKKKKKKKKKKKKKFFK'
 'KFFFFFFFFFFFFFFFFFFK'
 'KFFKKKKKKKKKKKKKKKKK'
 'KFFFFFFFFFFFFFFFFFFK'
 'KFFFFFFFFFFFFFFFFFFK'
 'KFFFFFFFFXFFFFFFFFFK'
 'KKKKKKKKKKKKKKKKKKKK',
 (-1, -1, -1, -1), ((9, 10, 13, 4, 6),),
 ((9, 1, 4, 2, 1, 'CORVIN here. My birds rule the sky!'),
  (8, 8, 3, 20, 3, 'Feel the wind!'),
  (1, 6, 3, 21, 3, "You can't fly past me!"),
  (18, 4, 3, 22, 2, 'Only one more step to CORVIN.')),
 -1),
('STARHAVEN GYM',
 'KKKKKKKKKKKKKKKKKKKK'
 'KFFFFFFFFFFFFFFFFFFK'
 'KFFFFFFFFFFFFFFFFFFK'
 'KFKFKFKFKFFKFKFKFKFK'
 'KFFFFFFFFFFFFFFFFFFK'
 'KFKFKFKFKFFKFKFKFKFK'
 'KFFFFFFFFFFFFFFFFFFK'
 'KFKFKFKFKFFKFKFKFKFK'
 'KFFFFFFFFFFFFFFFFFFK'
 'KFFFFFFFFFFFFFFFFFFK'
 'KFFFFFFFFXFFFFFFFFFK'
 'KKKKKKKKKKKKKKKKKKKK',
 (-1, -1, -1, -1), ((9, 10, 17, 15, 5),),
 ((9, 1, 4, 3, 1, 'I am ORLA. I foresaw your arrival.'),
  (3, 4, 3, 23, 3, 'I knew you would come this way.'),
  (16, 6, 3, 24, 2, 'Your next move is obvious to me.'),
  (10, 8, 3, 25, 1, 'Clear your mind... and battle!')),
 -1),
('POKEMON LEAGUE',
 'KKKKKKKKKKKKKKKKKKKK'
 'KKKKKKFFFFFFFFKKKKKK'
 'KKKKKKFFFFFFFFKKKKKK'
 'KKKKKKKKKFKKKKKKKKKK'
 'KKKKKKKFFFFFKKKKKKKK'
 'KKKKKKKKKFKKKKKKKKKK'
 'KKKKKKKFFFFFKKKKKKKK'
 'KKKKKKKKKFKKKKKKKKKK'
 'KKKKKKKFFFFFKKKKKKKK'
 'KKKKKKKKKFKKKKKKKKKK'
 'KKKKKKKXFFFFKKKKKKKK'
 'KKKKKKKKKKKKKKKKKKKK',
 (-1, -1, -1, -1), ((7, 10, 20, 10, 4),),
 ((9, 9, 8, 0, 1, 'I am BRANN of the ELITE FOUR. Feel the ICE!'),
  (9, 7, 8, 1, 1, 'DORRAN of the ELITE FOUR. The GROUND shakes!'),
  (9, 5, 8, 2, 1, 'MARISOL of the ELITE FOUR. Ride my WATER!'),
  (9, 3, 8, 3, 1, 'KESSA of the ELITE FOUR. Burn bright!'),
  (9, 1, 8, 4, 1, 'I am ALDRIC, the CHAMPION. Show me everything!')),
 -1),
)
START = (0, 3, 4, 1)
col = C.col
rect = C.rect
circ = C.circ
PATH = (222, 200, 150)
GRASS = (120, 200, 90)
TALL = (70, 165, 70)
WATER = (60, 120, 220)
ROCK = (140, 130, 120)
WALL = (235, 225, 205)
CFLOOR = (125, 100, 80)
CWALL = (60, 48, 42)
FLOOR = (215, 212, 200)
IWALL = (85, 78, 100)
DARK = (35, 115, 45)
BASE = {
    '.': PATH, ',': GRASS, ';': TALL, 'T': GRASS, 'f': GRASS, 'S': GRASS,
    '~': WATER, '#': ROCK, 'O': ROCK,
    'R': (205, 60, 60), 'B': (60, 100, 205), 'r': (160, 100, 60),
    'g': (140, 80, 170),
    'W': WALL, 'P': WALL, 'M': WALL, 'D': WALL, 'L': WALL, 'G': WALL,
    '=': (175, 125, 75), 'c': CFLOOR, 'k': CWALL,
    'F': FLOOR, 'X': FLOOR, 'K': IWALL,
}
DOOR = (90, 60, 40)
STRIPE = (0, 0, 0)
DET = {
    ';': ((DARK, ((0, 2, 8, 2, 6), (0, 7, 3, 2, 6), (0, 12, 8, 2, 6))),),
    'T': (((115, 75, 35), ((0, 6, 11, 4, 5),)), (DARK, ((1, 8, 7, 7),))),
    '~': (((160, 200, 250), ((0, 2, 5, 5, 2), (0, 9, 10, 5, 2))),),
    '#': (((100, 92, 85), ((0, 1, 11, 14, 4), (0, 9, 3, 5, 3))),),
    'f': (((230, 60, 80), ((0, 3, 3, 3, 3), (0, 10, 9, 3, 3))),
          ((250, 220, 60), ((0, 11, 3, 2, 2),))),
    'S': (((115, 75, 35), ((0, 7, 9, 2, 7),)), ((190, 140, 80), ((0, 2, 2, 12, 8),))),
    'O': ((STRIPE, ((0, 3, 5, 10, 11),)),),
    'R': (((150, 40, 40), ((0, 0, 12, 16, 4),)),),
    'B': (((40, 70, 150), ((0, 0, 12, 16, 4),)),),
    'r': (((115, 70, 40), ((0, 0, 12, 16, 4),)),),
    'g': (((240, 200, 60), ((0, 0, 12, 16, 3),)),),
    'W': (((120, 170, 220), ((0, 5, 4, 6, 6),)),),
    'P': ((DOOR, ((0, 4, 4, 8, 12),)), ((205, 60, 60), ((0, 6, 6, 4, 4),))),
    'M': ((DOOR, ((0, 4, 4, 8, 12),)), ((60, 100, 205), ((0, 6, 6, 4, 4),))),
    'D': ((DOOR, ((0, 4, 4, 8, 12),)),),
    'L': ((DOOR, ((0, 3, 4, 10, 12),)),),
    'G': ((DOOR, ((0, 3, 3, 10, 13),)), ((240, 200, 60), ((0, 6, 6, 4, 4),))),
    '=': (((130, 90, 50), ((0, 0, 3, 16, 2), (0, 0, 11, 16, 2))),),
    'c': (((95, 75, 60), ((0, 4, 6, 2, 2), (0, 11, 11, 2, 2))),),
    'k': (((85, 66, 56), ((0, 2, 2, 6, 5), (0, 9, 9, 5, 4))),),
    'F': (((195, 192, 180), ((0, 0, 14, 16, 2),)),),
    'K': (((65, 60, 80), ((0, 0, 12, 16, 4),)),),
    'X': (((180, 60, 60), ((0, 2, 9, 12, 7),)),),
}
def _shapes(layers, px, py):
    for c, shp in layers:
        col(c)
        for s in shp:
            if s[0]:
                circ(px + s[1], py + s[2], s[3])
            else:
                rect(px + s[1], py + s[2], s[3], s[4])
def tile(m, x, y):
    ch = m[y * 20 + x]
    px = x * 16
    py = y * 16
    col(BASE[ch])
    rect(px, py, 16, 16)
    d = DET.get(ch)
    if d:
        _shapes(d, px, py)
def rows(m, r0, r1):
    runs = {}
    for r in range(r0, r1):
        o = r * 20
        c = 0
        while c < 20:
            b = BASE[m[o + c]]
            e = c + 1
            while e < 20 and BASE[m[o + e]] is b:
                e += 1
            if b in runs:
                runs[b].append((c, r, e - c))
            else:
                runs[b] = [(c, r, e - c)]
            c = e
    for b in runs:
        col(b)
        for c, r, n in runs[b]:
            rect(c * 16, r * 16, n * 16, 16)
    runs = None
    lo = r0 * 20
    hi = r1 * 20
    for ch in DET:
        i = m.find(ch, lo, hi)
        if i < 0:
            continue
        pos = []
        while i >= 0:
            pos.append(i)
            i = m.find(ch, i + 1, hi)
        for c, shp in DET[ch]:
            col(c)
            for i in pos:
                px = (i % 20) * 16
                py = (i // 20) * 16
                for s in shp:
                    if s[0]:
                        circ(px + s[1], py + s[2], s[3])
                    else:
                        rect(px + s[1], py + s[2], s[3], s[4])
SKIN = (250, 210, 170)
LEGS = (50, 50, 70)
EYE = (20, 20, 20)
STYLE = (
    ((210, 40, 40), (40, 70, 180)),
    ((110, 70, 40), (60, 160, 80)),
    ((30, 30, 30), (240, 140, 40)),
    ((130, 60, 170), (240, 200, 60)),
    ((40, 50, 90), (150, 150, 160)),
    ((160, 160, 160), (250, 250, 250)),
)
def person(x, y, style, face, surf=0):
    px = x * 16
    py = y * 16
    cap, shirt = STYLE[style]
    if surf:
        col((240, 240, 240))
        rect(px + 1, py + 9, 14, 7)
    col(cap)
    rect(px + 4, py + 1, 8, 4)
    col(cap if face == 0 else SKIN)
    rect(px + 5, py + 5, 6, 4)
    col(shirt)
    rect(px + 4, py + 9, 8, 5)
    if not surf:
        col(LEGS)
        rect(px + 5, py + 14, 6, 2)
    if face:
        col(EYE)
        if face == 1:
            rect(px + 6, py + 6, 2, 2)
            rect(px + 9, py + 6, 2, 2)
        elif face == 2:
            rect(px + 5, py + 6, 2, 2)
        else:
            rect(px + 9, py + 6, 2, 2)

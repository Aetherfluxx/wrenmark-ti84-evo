# WRENMARK - part of WRENMARK for the TI-84 Evo (built by Dev/tools/build.py)
# Run this file. WRCORE, WRMAPS, WRBTL and WRTRN must also be on the calculator.
import gc
gc.collect()
try:
    import WRBTL as K
except ImportError:
    try:
        import wrbtl as K
    except ImportError:
        print('WRENMARK needs WRBTL.py on the calculator too.')
        raise
gc.collect()
try:
    import WRMAPS as D
except ImportError:
    try:
        import wrmaps as D
    except ImportError:
        print('WRENMARK needs WRMAPS.py on the calculator too.')
        raise
gc.collect()
try:
    import WRCORE as C
except ImportError:
    try:
        import wrcore as C
    except ImportError:
        print('WRENMARK needs WRCORE.py on the calculator too.')
        raise
gc.collect()
try:
    import WRTRN as Q
except ImportError:
    try:
        import wrtrn as Q
    except ImportError:
        print('WRENMARK needs WRTRN.py on the calculator too.')
        raise
gc.collect()
MAPS = D.MAPS
START = D.START
from time import sleep
CHEATS = set()
STEP = 0.06
SOLID = 'T~#RBrgWPMDLGSkK'
DOORS = 'PMDL'
ITEMS = K.ITEMS
FACE = ((0, -1), (0, 1), (-1, 0), (1, 0))
HALL = 25
SIGHT = 4
class G:
    m = 0
    x = 0
    y = 0
    f = 1
    surf = 0
    gyms = 0
    badges = 0
    money = 0
    bag = None
    party = None
    pc = None
    cap = 0
    capitem = 0
    home = None
    beat = None
    champ = 0
    e4 = 0
    slot = 0
T = ''
OBJ = ()
def new_game():
    G.m, G.x, G.y, G.f = START
    G.surf = 0
    G.gyms = 0
    G.badges = 0
    G.money = 1000
    G.bag = [5, 3, 0, 0]
    G.party = []
    G.pc = []
    G.cap = 0
    G.capitem = 0
    G.home = START[:3]
    G.beat = set()
    G.champ = 0
    G.e4 = 0
    G.slot = 0
    _set_map(G.m)
def _set_map(m):
    global T, OBJ
    G.m = m
    T = MAPS[m][1]
    OBJ = MAPS[m][4]
def can_pass(o):
    a = o[3]
    if 'ROAM' in CHEATS:
        return 1
    if a < 0:
        return len(G.party) > 0
    return G.badges >= a
def shown(o):
    k = o[2]
    if k == 2:
        return not can_pass(o)
    if k == 8:
        return o[3] >= G.e4
    return k == 0 or k == 3 or k == 4
def style(o):
    return (1, 0, 4, 2, 3, 0, 0, 5, 3)[o[2]]
def obj_at(x, y):
    for o in OBJ:
        if o[0] == x and o[1] == y:
            if (o[2] == 2 or o[2] == 8) and not shown(o):
                continue
            return o
    return None
def warp_at(x, y):
    for w in MAPS[G.m][3]:
        if w[0] == x and w[1] == y:
            return w
    return None
def player():
    D.tile(T, G.x, G.y)
    D.person(G.x, G.y, 0, G.f, G.surf)
def sprites(r0, r1):
    for o in OBJ:
        if r0 <= o[1] < r1 and shown(o):
            D.person(o[0], o[1], style(o), o[4])
    if r0 <= G.y < r1:
        D.person(G.x, G.y, 0, G.f, G.surf)
def bar():
    C.col((40, 40, 60))
    C.rect(0, 192, 320, 18)
    C.col(C.WHITE)
    C.txt(4, 193, MAPS[G.m][0])
def redraw(r0=0, r1=12):
    D.rows(T, r0, r1)
    sprites(r0, r1)
    if r1 >= 12:
        bar()
def after_box():
    redraw(9, 12)
def load(m, x, y):
    if G.m == HALL and m != HALL:
        G.e4 = 0
    _set_map(m)
    G.x = x
    G.y = y
    G.surf = 1 if T[y * 20 + x] == '~' else 0
    redraw()
def step(k):
    dx, dy, f = C.DIRS[k]
    G.f = f
    nx = G.x + dx
    ny = G.y + dy
    if nx < 0 or nx > 19 or ny < 0 or ny > 11:
        nb = MAPS[G.m][2][f]
        if nb < 0:
            player()
            return
        load(nb, nx % 20, ny % 12)
        spot()
        return
    w = warp_at(nx, ny)
    if w:
        load(w[2], w[3], w[4])
        spot()
        return
    o = obj_at(nx, ny)
    t = T[ny * 20 + nx]
    ghost = 'GHOST' in CHEATS
    if t in DOORS:
        player()
        interact()
        C.lock()
        return
    if not ghost:
        if o and shown(o):
            player()
            return
        if t == '~':
            if not ('ROAM' in CHEATS or G.badges >= 2):
                player()
                return
        elif t in SOLID:
            player()
            return
    D.tile(T, G.x, G.y)
    if ghost:
        o = obj_at(G.x, G.y)
        if o and shown(o):
            D.person(G.x, G.y, style(o), o[4])
    G.x = nx
    G.y = ny
    G.surf = 1 if t == '~' else 0
    D.person(nx, ny, 0, f, G.surf)
    if spot():
        return
    if t in ';c~' and 'PEACE' not in CHEATS and G.party:
        w = K.roll(MAPS[G.m][5], t)
        if w:
            battle(w)
def blackout():
    G.money //= 2
    G.e4 = 0
    load(G.home[0], G.home[1], G.home[2])
    heal()
    C.say('You hurried back to safety and lost half your money. Your POKEMON were healed.')
    after_box()
def battle(foe):
    if K.wild(G, foe, CHEATS) == 'lose':
        blackout()
        return
    K.evolve_all(G)
    redraw()
    C.lock()
def ready(o):
    k = o[2]
    if k == 3:
        return o[3] not in G.beat
    if k == 4:
        return not G.gyms >> o[3] & 1
    if k == 8:
        return o[3] == G.e4
    return False
def spot():
    if not G.party:
        return False
    for o in OBJ:
        if (o[2] != 3 and o[2] != 8) or not ready(o):
            continue
        dx, dy = FACE[o[4]]
        x, y = o[0], o[1]
        for n in range(SIGHT):
            x += dx
            y += dy
            if x < 0 or x > 19 or y < 0 or y > 11:
                break
            if x == G.x and y == G.y:
                by = o[1] * 16 - 16 if o[1] else 16
                C.box(o[0] * 16, by, 16, 16)
                C.col((220, 40, 40))
                C.txt(o[0] * 16 + 3, by - 1, '!')
                sleep(0.6)
                G.f = (1, 0, 3, 2)[o[4]]
                redraw()
                challenge(o)
                return True
            b = obj_at(x, y)
            if T[y * 20 + x] in SOLID or (b and shown(b)):
                break
    return False
def challenge(o):
    k = o[2]
    a = o[3]
    C.say(o[5])
    if k == 3:
        title, team = Q.TRAINERS[a]
        prize = Q.PRIZE * team[-1][1]
    elif k == 4:
        nm, badge, team = Q.LEADERS[a]
        title = 'LEADER ' + nm
        prize = 60 * team[-1][1]
    else:
        nm, team = Q.ELITE[a]
        title = ('CHAMPION ' if a == 4 else '') + nm
        prize = 80 * team[-1][1]
    if K.trainer(G, title, team, prize, CHEATS, k != 3) == 'lose':
        blackout()
        return
    K.evolve_all(G)
    if k == 3:
        G.beat.add(a)
    elif k == 4:
        G.gyms |= 1 << a
        G.badges = bin(G.gyms).count('1')
        redraw()
        C.say('You received the ' + badge + ' BADGE from ' + nm + '!')
        if a == 1:
            C.say('With the SPARK BADGE, your POKEMON can SURF. Just walk into water!')
        autosave()
    else:
        G.e4 = a + 1
        if a == 4:
            ending()
            return
        redraw()
        C.say(nm + ': Go on. The next challenger waits ahead.')
    redraw()
    C.lock()
def after_text(o):
    k = o[2]
    if k == 4:
        C.say(Q.LEADERS[o[3]][0] + ': You earned that BADGE. Keep going!')
    elif k == 8:
        C.say(Q.ELITE[o[3]][0] + ': Go on ahead.')
    else:
        C.say('That was a great battle!')
def ending():
    G.champ = 1
    C.col((20, 30, 60))
    C.rect(0, 0, 320, 210)
    C.col((250, 220, 60))
    C.txt(80, 14, 'CONGRATULATIONS!')
    C.col(C.WHITE)
    C.txt(20, 40, 'You are the new CHAMPION')
    C.txt(80, 60, 'of WRENMARK!')
    n = len(G.party)
    for i in range(n):
        C.icon(160 - (n - 1) * 25 + i * 50, 112, G.party[i][0], 16)
    C.col((250, 220, 60))
    C.txt(130, 150, 'THE END')
    C.col(C.WHITE)
    C.txt(65, 172, 'Thanks for playing!')
    C.wait_ab()
    G.e4 = 0
    load(20, 10, 4)
    heal()
    if G.slot:
        autosave()
    elif C.ask('Save your game as CHAMPION?'):
        save_menu()
    after_box()
def interact():
    dx, dy = FACE[G.f]
    x = G.x + dx
    y = G.y + dy
    if x < 0 or x > 19 or y < 0 or y > 11:
        return
    o = obj_at(x, y)
    t = T[y * 20 + x]
    if o:
        k = o[2]
        if shown(o):
            D.tile(T, x, y)
            D.person(x, y, style(o), (1, 0, 3, 2)[G.f])
        if k == 6:
            home()
        elif k == 7:
            lab()
        elif k == 3 or k == 4 or k == 8:
            if not G.party:
                C.say(o[5])
            elif ready(o):
                challenge(o)
                return
            else:
                after_text(o)
        else:
            C.say(o[5])
    elif t == 'P':
        center()
        return
    elif t == 'M':
        mart()
        return
    elif t == 'D':
        C.say('Nobody seems to be home.')
    else:
        return
    after_box()
def heal():
    for p in G.party:
        p[3] = C.maxhp(p)
    G.home = (G.m, G.x, G.y)
def center():
    C.say('Welcome to the POKEMON CENTER!', 0)
    while 1:
        c = C.menu(('HEAL', 'PC', 'LEAVE'), 200, 30, 116)
        if c == 0:
            heal()
            redraw(0, 12)
            C.say('Your POKEMON are fully healed. Come again!')
            break
        if c == 1:
            C.pc_menu(G)
            redraw(0, 12)
            C.say('Welcome to the POKEMON CENTER!', 0)
        else:
            break
    redraw(0, 12)
def home():
    C.say('MOM: Welcome home, dear! Have a rest.')
    heal()
    C.say('You and your POKEMON feel refreshed.')
def lab():
    if not G.party:
        C.say('PROF. LINDEN: There you are! Every journey needs a partner POKEMON. Pick one!')
        sp = -1
        while sp < 0:
            sp = C.choose_starter()
        G.party.append(C.mk(sp, 5))
        redraw()
        C.say('You received ' + C.SPECIES[sp][0] + '! Take good care of it.')
        G.capitem = 1
        C.say('PROF. LINDEN: Take this LEVEL CAP too. Set it from your BAG to make strong POKEMON battle at a lower level.')
        C.say('You received the LEVEL CAP!')
        C.say('PROF. LINDEN: Earn 4 BADGES, then take on the LEAGUE. Good luck!')
    else:
        C.say('PROF. LINDEN: Earn 4 BADGES, then take on the LEAGUE!')
def pick_slot(q):
    C.say(q, 0)
    c = C.menu([Q.label(i) for i in range(1, Q.SLOTS + 1)], 10, 40, 300)
    return c + 1 if c >= 0 else 0
def save_menu():
    s = pick_slot('Save to which slot?')
    if not s:
        return
    if Q.peek(s) and s != G.slot and not C.ask('Overwrite SLOT ' + str(s) + '?'):
        return
    try:
        Q.save(G, s)
        C.say('Game saved to SLOT ' + str(s) + '.')
    except Exception as e:
        C.say('Save failed! ' + str(e))
def load_menu():
    s = pick_slot('Load which slot?')
    if not s:
        return False
    if not Q.peek(s):
        C.say('SLOT ' + str(s) + ' is empty.')
        return False
    try:
        Q.load(G, s)
    except Exception as e:
        C.say('Load failed! ' + str(e))
        return False
    load(G.m, G.x, G.y)
    C.say('Loaded SLOT ' + str(s) + '.')
    after_box()
    return True
def autosave():
    if G.slot:
        try:
            Q.save(G, G.slot)
            C.say('Game saved to SLOT ' + str(G.slot) + '.')
        except Exception:
            C.say('Autosave failed! Save from the menu.')
def continue_menu():
    if not Q.any_save():
        return False
    while 1:
        c = C.menu(('CONTINUE', 'NEW GAME'), 100, 84, 120)
        if c == 1:
            return False
        if c == 0:
            s = pick_slot('Continue which slot?')
            if s and Q.peek(s):
                try:
                    Q.load(G, s)
                    _set_map(G.m)
                    return True
                except Exception as e:
                    C.say('Load failed! ' + str(e))
def money_box():
    C.box(4, 4, 130, 28)
    C.col(C.BLACK)
    C.txt(12, 8, '$' + str(G.money))
def mart():
    C.say('Welcome to the MART! What do you need?', 0)
    stock = [i for i in range(len(ITEMS)) if ITEMS[i][2] <= G.badges]
    names = []
    for i in stock:
        n, p, b = ITEMS[i]
        s = str(p)
        names.append(n + ' ' * (17 - len(n) - len(s)) + s)
    sel = 0
    while 1:
        money_box()
        sel = C.menu(names, 100, 40, 216, sel)
        if sel < 0:
            break
        i = stock[sel]
        p = ITEMS[i][1]
        if G.money < p:
            C.say("You don't have enough money.")
        else:
            G.money -= p
            G.bag[i] += 1
            C.say('Bought a ' + ITEMS[i][0] + '. You have ' + str(G.bag[i]) + '.', 0)
    redraw(0, 12)
def bag_view():
    K.bag_menu(G)
def trainer_card():
    got = [Q.LEADERS[i][1] for i in range(4) if G.gyms >> i & 1]
    C.say('MONEY: $' + str(G.money) + '|BADGES: ' + (' '.join(got) if got else 'none') +
          ('|CHAMPION!' if G.champ else ''))
def safe_spot(m):
    t = MAPS[m][1]
    best = None
    for y in range(12):
        for x in range(20):
            if t[y * 20 + x] in SOLID or t[y * 20 + x] in 'GOX':
                continue
            if any(o[0] == x and o[1] == y for o in MAPS[m][4]):
                continue
            d = abs(x - 9) + abs(y - 7)
            if best is None or d < best[0]:
                best = (d, x, y)
    return best[1], best[2]
def warp_menu():
    v = C.num_pick('WARP TO', G.m, 0, len(MAPS) - 1, 5,
                   lambda i: MAPS[i][0], 1)
    if v is None:
        return False
    x, y = safe_spot(v)
    load(v, x, y)
    return True
def menu_opts():
    opts = ['POKEMON', 'BAG', 'TRAINER', 'SAVE', 'LOAD']
    if 'TOOLKIT' in CHEATS:
        opts.append('EDITOR')
    if 'WARP' in CHEATS:
        opts.append('WARP')
    return opts + ['QUIT', 'CLOSE']
def start_menu():
    while 1:
        opts = menu_opts()
        c = C.menu(opts, 200, 4, 116)
        o = opts[c] if c >= 0 else 'CLOSE'
        if o == 'POKEMON':
            C.party_menu(G)
        elif o == 'BAG':
            bag_view()
        elif o == 'TRAINER':
            trainer_card()
        elif o == 'SAVE':
            redraw(0, 12)
            save_menu()
        elif o == 'LOAD':
            redraw(0, 12)
            if load_menu():
                return False
        elif o == 'EDITOR':
            C.editor(G)
        elif o == 'WARP':
            if warp_menu():
                return False
        elif o == 'QUIT':
            redraw(0, 12)
            if C.ask('Quit the game? Anything not saved will be lost.'):
                return True
        redraw(0, 12)
        if o == 'CLOSE':
            return False
def run():
    redraw()
    while 1:
        k = C.key(1)
        if k in C.DIRS:
            step(k)
            if 'TURBO' not in CHEATS:
                sleep(STEP)
        elif k in C.A_KEYS:
            interact()
        elif k == C.CLEAR or k == C.MODE:
            if start_menu():
                return
def mem():
    try:
        import gc
        gc.collect()
        return str(gc.mem_free())
    except Exception:
        return '?'
CODES = (
    ('TOOLKIT', (C.UP, C.UP, C.DOWN, C.DOWN, C.LEFT, C.RIGHT, C.LEFT, C.RIGHT, C.SECOND)),
    ('ROAM', (C.DOWN, C.DOWN, C.DOWN, C.UP, C.UP, C.UP, C.SECOND)),
    ('TURBO', (C.RIGHT, C.RIGHT, C.RIGHT, C.RIGHT, C.SECOND)),
    ('WARP', (C.UP, C.RIGHT, C.DOWN, C.LEFT, C.UP, C.RIGHT, C.DOWN, C.LEFT, C.SECOND)),
    ('GHOST', (C.LEFT, C.LEFT, C.LEFT, C.RIGHT, C.RIGHT, C.RIGHT, C.SECOND)),
    ('PEACE', (C.UP, C.UP, C.UP, C.UP, C.SECOND)),
    ('LUCKY', (C.DOWN, C.DOWN, C.DOWN, C.DOWN, C.SECOND)),
    ('POWER', (C.LEFT, C.LEFT, C.LEFT, C.LEFT, C.SECOND)),
)
def banner():
    C.col((120, 200, 90))
    C.rect(0, 150, 320, 60)
    C.col((250, 220, 60))
    C.txt(110, 150, 'CHEATS ON:')
    ls = C.wrap(' '.join([n for n, c in CODES if n in CHEATS]), 31)
    for i in range(len(ls)):
        C.txt(160 - len(ls[i]) * 5, 168 + i * 18, ls[i])
def title():
    C.col((30, 60, 40))
    C.rect(0, 0, 320, 210)
    C.col((120, 200, 90))
    C.rect(0, 150, 320, 60)
    C.col((250, 220, 60))
    C.txt(120, 40, 'WRENMARK')
    C.col(C.WHITE)
    C.txt(50, 70, 'A tiny monster journey')
    C.txt(105, 120, 'PRESS ENTER')
    C.col((90, 130, 100))
    C.txt(4, 2, 'free mem ' + mem())
    seq = []
    while 1:
        k = C.key()
        if k == C.ENTER:
            return
        seq = (seq + [k])[-9:]
        for n, c in CODES:
            if tuple(seq[-len(c):]) == c and n not in CHEATS:
                CHEATS.add(n)
                banner()
def intro():
    redraw()
    C.say('Hello! I am PROF. LINDEN. Welcome to the WRENMARK region!')
    C.say('POKEMON live everywhere here. People train them and battle for fun.')
    C.say('Come to my lab, the big building south of your house. Your journey starts now!')
    after_box()
def main():
    title()
    new_game()
    if not continue_menu():
        new_game()
        intro()
    run()
    C.col(C.BLACK)
    C.rect(0, 0, 320, 210)
    C.col(C.WHITE)
    C.txt(65, 90, 'Thanks for playing!')
main()

# WRTRN - part of WRENMARK for the TI-84 Evo (built by Dev/tools/build.py)
try:
    import WRCORE as C
except ImportError:
    try:
        import wrcore as C
    except ImportError:
        print('WRENMARK needs WRCORE.py on the calculator too.')
        raise
TRAINERS = (
    ('YOUNGSTER', ((11, 4), (9, 4))),
    ('CAMPER', ((17, 6), (13, 6))),
    ('LASS', ((9, 6), (11, 7))),
    ('HIKER', ((22, 10), (15, 11))),
    ('CAMPER', ((19, 11), (11, 11))),
    ('HIKER', ((22, 12), (24, 13), (15, 12))),
    ('ENGINEER', ((19, 15), (19, 16))),
    ('LASS', ((27, 15), (29, 16))),
    ('SWIMMER', ((25, 22), (27, 23))),
    ('BIRDER', ((10, 26), (21, 27))),
    ('MYSTIC', ((37, 26), (17, 27))),
    ('SKIER', ((31, 31), (33, 32))),
    ('SKIER', ((33, 31), (16, 33))),
    ('SWIMMER', ((26, 35), (28, 35))),
    ('MYSTIC', ((35, 34), (37, 36))),
    ('ACE', ((23, 44), (32, 45))),
    ('ACE', ((20, 44), (36, 45), (28, 45))),
    ('HIKER', ((22, 11),)),
    ('ENGINEER', ((19, 19), (21, 20))),
    ('ENGINEER', ((21, 20), (19, 21))),
    ('BIRDER', ((10, 28),)),
    ('BIRDER', ((21, 28), (9, 27))),
    ('BIRDER', ((34, 30),)),
    ('MYSTIC', ((37, 36), (35, 36))),
    ('MYSTIC', ((17, 36), (38, 37))),
    ('MYSTIC', ((36, 38),)),
)
PRIZE = 20
LEADERS = (
    ('TAMSIN', 'FLINT', ((22, 12), (24, 14))),
    ('EZRA', 'SPARK', ((19, 21), (21, 21), (20, 24))),
    ('CORVIN', 'GALE', ((10, 32), (21, 32), (34, 34), (36, 35))),
    ('ORLA', 'MIND', ((38, 38), (18, 38), (36, 39), (38, 41))),
)
ELITE = (
    ('BRANN', ((32, 48), (34, 48), (31, 49), (32, 51))),
    ('DORRAN', ((16, 49), (14, 49), (24, 50), (16, 52))),
    ('MARISOL', ((26, 50), (28, 50), (8, 51), (26, 53))),
    ('KESSA', ((30, 51), (5, 52), (30, 52), (30, 54))),
    ('ALDRIC', ((12, 55), (20, 56), (23, 56), (38, 57), (10, 57), (2, 58))),
)
from ti_system import store_list, recall_list
VER = 1
SLOTS = 3
def pack(p):
    return [p[0], p[2], p[3], p[4] * 1000000 + p[5] * 10000 + p[6] * 100 + p[7]]
def unpack(v, i):
    sp, ex, hp, mv = [int(round(x)) for x in v[i:i + 4]]
    lv = 1
    while lv < 100 and C.exp_at(lv + 1) <= ex:
        lv += 1
    return [sp, lv, ex, hp, mv // 1000000, mv // 10000 % 100, mv // 100 % 100, mv % 100]
def peek(slot):
    try:
        d = recall_list('WRS' + str(slot))
        if d and int(round(d[0])) == VER:
            return d
    except Exception:
        pass
    return None
def any_save():
    for s in range(1, SLOTS + 1):
        if peek(s):
            return True
    return False
def save(G, slot):
    beat = 0
    for t in G.beat:
        beat |= 1 << t
    d = [VER, G.m, G.x, G.y, G.f, G.gyms, G.money] + G.bag + \
        [G.cap, G.capitem] + list(G.home) + [beat, G.champ, len(G.pc), len(G.party)]
    for p in G.party:
        d += pack(p)
    pc = []
    for p in G.pc:
        pc += pack(p)
    store_list('WRP' + str(slot) + 'A', pc[:100] or [0])
    store_list('WRP' + str(slot) + 'B', pc[100:200] or [0])
    store_list('WRS' + str(slot), d)
    G.slot = slot
def load(G, slot):
    d = [int(round(x)) for x in recall_list('WRS' + str(slot))]
    G.m, G.x, G.y, G.f, G.gyms, G.money = d[1:7]
    G.bag = d[7:11]
    G.cap, G.capitem = d[11], d[12]
    G.home = (d[13], d[14], d[15])
    G.beat = set(i for i in range(32) if d[16] >> i & 1)
    G.champ = d[17]
    npc, npar = d[18], d[19]
    G.party = [unpack(d, 20 + 4 * i) for i in range(npar)]
    pc = list(recall_list('WRP' + str(slot) + 'A')) + list(recall_list('WRP' + str(slot) + 'B'))
    G.pc = [unpack(pc, 4 * i) for i in range(npc)]
    G.badges = bin(G.gyms).count('1')
    G.e4 = 0
    G.slot = slot
def label(slot):
    d = peek(slot)
    if not d:
        return 'SLOT ' + str(slot) + '  (empty)'
    b = bin(int(round(d[5]))).count('1')
    return 'SLOT ' + str(slot) + '  ' + str(b) + ' BADGE' + ('' if b == 1 else 'S') + \
        '  $' + str(int(round(d[6])))
